## ArchView Data Specification - Lean Mode

ArchView (also referred to as "the archview") is generated solely from the input file ***archview.json*** (containing ViewInfo data, and Graph image data) in the assets directory. Here is the structure of archview.json:

```
{
"viewInfo":[
{
"Title": "Title info",
"Description": "<p>Brief summary</p>",
"Area": "Lean-mode",
"Status": "",
"Implication": ""
}
],
  "groups": [
    {
      "id": "g1",
      "label": "g1 title",
      "style": "solid",
      "gcolor": ""
    },
    {
      "id": "g2",
      "label": "g2 title",
      "style": "line",
      "gcolor": "beige"
    }
  ],
  "nodes": [
    {
      "id": "n1",
      "group": "g1",
      "image": "AA",
      "label": "n1 title",
"properties": ""
    },
    {
      "id": "n2",
      "group": "g1",
      "image": "AA",
      "label": "n2 title",
      "properties": ""
    }
  ],
  "edges": [
    {
      "id": "e1",
      "source": "n1",
      "target": "n2",
      "type": "arrow",
      "label": "link e1",
      "link": ""
    },
    {
      "id": "e2",
      "source": "g1",
      "target": "g2",
      "type": "arrow",
      "label": "link e2",
      "link": "group"
    }
  ]
}
```

For this lean-mode view, leave the **Status** and **Implication** (in the viewInfo), and the **properties** (in the nodes) blank, as they only apply to the standard ArchView specification.

### ViewInfo data

ViewInfo data includes the required View Title and View Area, and View Description. Every view should include at least a brief summary.

1. **Title**: Keep it short and clearly indicative of the view. It can include the project name, the view's key idea, a pattern name, and so on.
2. **Area**: Just input as "Lean", or "Lean-mode". The code will generate the lean-mode view.
3. **Description**: Use simple HTML (`<p>` and `<b>`) and give a brief summary of the architectural focus for the given area, the architectural mapping process and actions taken, and, optionally, any metrics, trade-offs, governance or techniques implied by the view image or property list. Descriptions should be concise, succinct, and tailored to the intended audience, whether highly technical (developers) or non-technical (naive users). When elaborating, you can cover the action status, assumptions, relevance, or potential enhancements based on the input provided.

The architectural essence should be reflected in the view itself: a good architectural view, or set of views, should be mostly self-explanatory. 

### View Graph Data

ArchView graph data follows the format in the table below and the rules in the *ArchView Guidance* section of this document, plus the rules in the SKILL.md.

Note that a node's prefix determines its architectural characteristics and mappings. That said, each node's title (or label) should still carry a meaningful architectural description suited to the user's level of understanding.

| Item  | Attribute  | Description                       | Usage Example                                                                                                                  |
| ----- | ---------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| group | id         | unique group id                   | First letter "g" + auto index, i.e., g1                                                                                        |
| group | label      | group's title                     |                                                                                                                                |
| group | style      | border style                      | solid \| dotted                                                                                                                |
| group | gcolor     | group-box's background color      | "white" as default for the generic or cross-cutting group. See Rule-G3.                                                        |
| node  | id         | unique node id                    | First letter "n" + auto index, i.e., n1                                                                                        |
| node  | group      | the group id the node belongs to  |                                                                                                                                |
| node  | image      | node's image prefix               | A two-letter code corresponding to its prefix in the following ESA element specification.                                      |
| node  | label      | node's/image's title              | Follows the Rule-N1 naming convention. The title wraps automatically, but Rule-N3 gives suggested length limits.               |
| node  | properties | element property list             | leave it blank for this lean-mode                                                                                              |
| edge  | id         | unique edge id                    |                                                                                                                                |
| edge  | source     | the id of the link's start node   |                                                                                                                                |
| edge  | target     | the id of the link's end node     |                                                                                                                                |
| edge  | type       | the edge/link's end pointer style | arrow \| line                                                                                                                  |
| edge  | label      | the link title                    | Keep it very short: an action verb or protocol name.                                                                           |
| edge  | link       | the type of element being linked  | "group" for a link between two group-boxes; "" (default) for a link between two nodes. See also Rule-E1, Rule-E2, and Rule-E3. |

### Element Prefix Notation Info

If the view's description input is not blank (which should not be), the output html will include a list of prefixed element types shown in the graph image. The prefix notation information will be handled automatically from the code.

## ArchView Output

The output is a self-contained, single-page HTML file that includes a generated SVG image and the view info, with these menu options: save as image, copy to clipboard, save as a PDF report (containing both the ArchView image and view info), and toggle between move/zoom (also available via mouse wheel). Users can reposition groupboxes or nodes using the mouse movement to customize the layout. The output page also includes panning functionality for the graph.

## ArchView Samples

See the following input and output samples for the lean-mode view in the references directory:

- *archview-lean-mode-image-sample.png*
- *archview-lean-mode-output-sample.html*
- *archview-lean-mode-report-sample.pdf*

# ArchView Guidance

## ArchView Specification (Lean-Mode)

### ArchView Element List

Each lean-mode element is defined in the following archview element specification list.  

| Element           | Prefix | Brief Definition                                                                                                                | Implication                                |
| ----------------- | ------ | ------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------ |
| Requirement       | RQ     | Represents a concise statement of needs, quality expectations, and acceptance criteria the solution must satisfy.               | Non-Functional Requirement, Rule, Intent   |
| Key Choice        | KC     | Represents an architecturally significant decision, including trade-offs and rationale.                                         | Key Decision and Consideration, Governance |
| Service Component | SC     | Represents a component that implements and delivers a specific service responsibility or capability.                            | Component, Object                          |
| Data Store        | DB     | Represents a repository where structured, semi-structured, or unstructured data is persisted and managed.                       | Database, Storage                          |
| Middleware        | MW     | Represents productized system software that provides common services and integration capabilities to applications and services. | Development, System or Platform Software   |
| Node              | ND     | Represents the physical and virtual compute resources that host and execute the solution.                                       | Deployment Package                         |
| System            | SY     | Represents a collection of hardware and software pieces and a set of relationships for specific functions.                      | Device                                     |
| Role              | RO     | Represents a user, user group, or stakeholder responsible for performing specific behaviors or responsibilities.                | Actor, User, Stakeholder                   |
| Task              | TK     | Represents a piece of work assigned to a role within a process.                                                                 | Activity, State                            |
| Grouping          | GP     | Represents a logical layer, composition, aggregation, or organization of related elements.                                      | Group, Domain                              |
| Generic Service   | GS     | Represents a conceptual business or application capability used to describe solution behavior at a high level.                  | Service, Application, General Element      |
| Note              | NT     | Represents commentary, interpretation, or supplementary information about the architecture.                                     | Key Element Properties, Artifact           |

Each element id is represented by a two-letter prefix as the node image value. The script handles the real image mapping.

The choice of elements depends on the solution's needs and architectural style(s). You can select a subset of lean-mode elements for a given view. Since lean-mode has a limited element set, you should aim for approximate matching when selecting elements.

### ArchView Area

Lean mode does not designate a specific view area. Instead, the relevant area is loosely indicated within the *title* or the view *description*.

## ArchView Rules

The following rules apply specifically to this data specification, other than the rules specified in the SKILL.md that apply to both this lean-mode specification and the standard specification.

### Rendering Rules

**Group**

- Rule-G2: For the group box that represents a domain, composition or physical grouping or layering, use solid border. For the conceptual or logical grouping, use dotted border.

- Rule-G3: Optionally, use color to distinguish the ESA nature of the elements within a group. The group colors include:
  
  - ivory [#FFFFF0] for a user/channel group
  - honeydew [#F0FFF0] for a functional/application group
  - beige [#F5F5DC] for an operational/deployment group

**Node**

- Rule-N1: A node's label starts with a two-letter prefix (e.g., SY for system) as defined in archview-elements.md, followed by an index (dash + number), a space, and the title description, for example, SY-11 CRM Application Suite. Adding an index is optional, but it's a common convention for easy correlation. If the view is very simple, just specify the element prefix.

- Rule-N4: Keep the total node count per view under around 20 if there are multiple edges, or under around 30 if there are few or no edges. For a relatively complex solution, split the view into multiple views.
