## ArchView Data Specification

ArchView (also referred to as "the archview") is generated solely from the input file ***archview.json*** (containing ViewInfo data, Graph image data, and Properties data) in the assets directory. Here is the structure of archview.json:

```
{
"viewInfo":[
{
"Title": "Title info",
"Description": "<p>Brief summary</p>",
"Area": "Overall-solution",
"Status": "Testing Stage",
"Implication": "<p>The complete model needs also to consider the following views:</p><p><b>Capability View</b> (an overview) - Focusing on ABC </p>"
}
],
  "groups": [
    {
      "id": "g1",
      "label": "g1 title",
      "style": "solid",
      "gcolor": ""
    },
    {
      "id": "g2",
      "label": "g2 title",
      "style": "line",
      "gcolor": "beige"
    }
  ],
  "nodes": [
    {
      "id": "n1",
      "group": "g1",
      "image": "AA",
      "label": "n1 title",
"properties": "property1=attribute1|property2=attribute2"
    },
    {
      "id": "n2",
      "group": "g1",
      "image": "AA",
      "label": "n2 title",
      "properties": ""
    }
  ],
  "edges": [
    {
      "id": "e1",
      "source": "n1",
      "target": "n2",
      "type": "arrow",
      "label": "link e1",
      "link": ""
    },
    {
      "id": "e2",
      "source": "g1",
      "target": "g2",
      "type": "arrow",
      "label": "link e2",
      "link": "group"
    }
  ]
}
```

### ViewInfo data

ViewInfo data includes the required View Title and View Area, plus View Description, Status, and Implication. Every view should include at least a brief summary; for a complete ArchView model, write out all the listed items in the view description concisely, with relevant content.

1. **Title**: Keep it short and clearly indicative of the view. It can include the project name, the view's key idea, a pattern name, and so on.
2. **Area**: Must be one of: Business, Use-case, Metrics, Overall-solution, Functional, or Operational. "Overall-solution" covers architecture overview or building-block views, solution capability views, DevOps, end-to-end (walk-through) verification, integration or cross-cutting views, and/or pattern views. "Functional" covers high-level application design views, application/technical relationship views, AI (autonomous intelligence) views, and data relationship views. "Operational" covers deployment and infrastructure views.
3. **Description**: Use simple HTML (`<p>` and `<b>`) and give a brief summary of the architectural focus for the given area, the architectural mapping process and actions taken, and, optionally, any metrics, trade-offs, or techniques implied by the view image or property list. For example:
   - **Significant requirements and metrics**: 1) the key stated and implicit requirements (up to 3), 2) the quality attributes being measured (both feasible and realizable), and 3) optionally, potential heat-maps (enterprise/business) or hotspots (solutions), or simply a checklist covering performance (stress simulation, throughput/bandwidth, storage capacity), availability (redundancy, throttling, degrading, rollback), security (digital control, firewall, cloud workload), maintainability (changeability, monitoring, tracing), and cost (ROI, resource utilization). Note the governance measures, scalable action points, or elastic platform choices, and how they show up in the views.
   - **Concrete governance actions**: governance functions within the application, governance controls at runtime, and human oversight where needed.
   - **Architectural techniques**: layering and partitioning, including the applicable principles, patterns, assets, or styles (e.g., cloud architecture, microservice architecture, integration architecture, AI architecture, application architecture or design, infrastructure architecture, business architecture, enterprise architecture, or a mixed style), and why they were chosen.
   - **Key trade-offs**: the significant trade-offs (1–3) considered in the view, or how the view's elements map to the requirements, stated concisely.
4. **Status**: Indicate whether this is a one-time model/view, what stage it's at or a confidence indicator (Draft, Stakeholder-Reviewed, Governance-of-Record), any role assignments, and optionally the degree of readiness, and so on.
5. **Implication**: State assumptions, relevance, further enhancements, recommendations, or action items, in particular how this view relates to others, if any, and what other views are needed to complete an ArchView model for the solution, per the ArchView specification of elements and view areas. State the part you are unsure of, if any. For large, complex enterprise-level solutions, reaching stakeholder agreement (from both business and technical viewpoints) on the model views through iteration is critical.
6. **Timestamp**: Note the date and time for version reference.

Also use the description to explain or clarify architectural-level terms, such as domain, generic service, context state, view frame, and virtual service, to see how they are applied to the solution's context.

The detailed level of the view description is flexible, depending on the view's complexity and the user's needs. Its essence should already be reflected in the view itself: a good architectural view, or set of views, should be mostly self-explanatory. A validated model should be agreed on by all identified stakeholders of the architecture.

Note: if the view description is left blank, the output contains only the view graph image, without the PDF report or properties menu options. For simple solutions or novice users, use the *archview-data-specification-lean-mode.md* instead.

### View Graph Data

ArchView graph data follows the format in the table below and the rules in the *ArchView Guidance* section of this document.

Note that a node's prefix determines its architectural characteristics and mappings. That said, each node's title (or label) should still carry a meaningful architectural description suited to the user's level of understanding.

| Item  | Attribute  | Description                       | Usage Example                                                                                                                  |
| ----- | ---------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| group | id         | unique group id                   | First letter "g" + auto index, i.e., g1                                                                                        |
| group | label      | group's title                     |                                                                                                                                |
| group | style      | border style                      | solid \| dotted                                                                                                                |
| group | gcolor     | group-box's background color      | "white" as default for the generic or cross-cutting group. See Rule-G3.                                                        |
| node  | id         | unique node id                    | First letter "n" + auto index, i.e., n1                                                                                        |
| node  | group      | the group id the node belongs to  |                                                                                                                                |
| node  | image      | node's image prefix               | A two-letter code corresponding to its prefix in thefollowing ESA element specification.                                       |
| node  | label      | node's/image's title              | Follows the Rule-N1 naming convention. The title wraps automatically, but Rule-N3 gives suggested length limits.               |
| node  | properties | element property list (optional)  | A concatenated string of property=attribute pairs, grouped by \| as specified in Rule-N2                                       |
| edge  | id         | unique edge id                    | First letter "e" + auto index, i.e., e1                                                                                        |
| edge  | source     | the id of the link's start node   |                                                                                                                                |
| edge  | target     | the id of the link's end node     |                                                                                                                                |
| edge  | type       | the edge/link's end pointer style | arrow \| line                                                                                                                  |
| edge  | label      | the link title                    | Keep it very short: an action verb or protocol name.                                                                           |
| edge  | link       | the type of element being linked  | "group" for a link between two group-boxes; "" (default) for a link between two nodes. See also Rule-E1, Rule-E2, and Rule-E3. |

### Properties Data

Element properties are part of view graph data. The element property list is optional, but required when elements contain long text and/or additional property attributes that don't fit in the graph view, or complex solutions. For a complex view, keep node labels/titles short, and describe the details as a list of property/attribute pairs for the elements that need it.

### Element Prefix Notation Info

If the view's description input is not blank (which should not be), the output html will include a list of elements on the view in terms of their spelled-out names, ESA bearing or relevance and belonging category. The prefix notation information will be handled automatically from the code.

## ArchView Output

The output is a self-contained, single-page HTML file that includes a generated SVG image and the view info, with these menu options: zoom (also available via mouse wheel), pan, move (for repositioning groupboxes or nodes to customize the layout), save as image, copy to clipboard, save as JSON (for record-keeping and further chat context), save as a PDF report (containing both the ArchView image and view info), toggle between the view and its properties, and toggle between move/zoom.

## ArchView Samples

See the following input and output samples in the references directory:

- *archview-sample-input.json*
- *archview-sample-output.html*
- *archview-sample-report.pdf*

# ArchView Guidance

## ArchView Specification

### ArchView Element List

Each view element is defined in the following archview element specification list.  

| Section                     | Category                     | Element                | Prefix | Brief Definition                                                                                                                                                       | Implication                           | Base Mapping                     |
| --------------------------- | ---------------------------- | ---------------------- | ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------- | -------------------------------- |
| Part 1 - Base Elements      | Intent & Metrics             | Intent (Optional)      | IT     | Represents the strategic intent, value drivers, visions that justify and direct the solution.                                                                          | Value, Objective                      |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Capability             | CP     | Represents the business, technical and AI capabilities the solution enables or delivers.                                                                               | Value, Service Capability             |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Use Case               | UC     | Represents the interactions between a role and a system to achieve a goal.                                                                                             | Case Scenario, User Story             |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Principle              | PR     | Represents a qualitative statement that must be met by the architecture.                                                                                               | Policy                                |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Risk                   | RK     | Represents a potential issue, event, or condition that may occur and requires mitigation or management.                                                                | Constraints                           |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Requirement            | RQ     | Represents a concise statement of needs, quality expectations, and acceptance criteria the solution must satisfy.                                                      | Non-Functional Requirement, Rule      |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Key Choice             | KC     | Represents an architecturally significant decision, including trade-offs and rationale.                                                                                | Key Decision and Consideration        |                                  |
| Part 1 - Base Elements      | Intent & Metrics             | Governance             | GV     | Represents the policies, compliance obligations, ethical controls, and accountability structures that guide responsible solution behavior.                             | Validation                            |                                  |
| Part 1 - Base Elements      | Functional -Application      | Access Interface       | UI     | Represents the interaction channels, UX, UI surfaces, and entry points through which users engage with the solution.                                                   | GUI, CLI, Voice, Media                |                                  |
| Part 1 - Base Elements      | Functional / Application     | App Logic              | AS     | Represents explicitly defined non-GUI application behaviors and control logic.                                                                                         |                                       |                                  |
| Part 1 - Base Elements      | Functional / Application     | Data Service           | DS     | Represents a self-contained piece of information that has a clear and consistent meaning to the business.                                                              | Data Object, Data Federation          |                                  |
| Part 1 - Base Elements      | Functional / Application     | Technical Service      | TS     | Represents a self-contained, reusable technical capability agnostic of business-specific logic.                                                                        | Utility Service                       |                                  |
| Part 1 - Base Elements      | Functional / Application     | Interface              | SI     | Represents a point of access where services are exposed to services or service components.                                                                             | Service Interface, API                |                                  |
| Part 1 - Base Elements      | Functional / Application     | Service Component      | SC     | Represents a component that implements and delivers a specific service responsibility or capability.                                                                   |                                       |                                  |
| Part 1 - Base Elements      | Functional / Application     | Application            | AP     | Represents a bounded software system that delivers business capabilities through integrated user interfaces, application logic, data services, and technical services. |                                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Deployment Package     | DP     | Represents a deployable package of functional services with unique service-level characteristics.                                                                      | Deployment Unit                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Data Store             | DB     | Represents a repository where structured, semi-structured, or unstructured data is persisted and managed.                                                              |                                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Middleware             | MW     | Represents productized system software that provides common services and integration capabilities to applications and services.                                        |                                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Node                   | ND     | Represents the physical and virtual compute resources that host and execute the solution.                                                                              |                                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | System                 | SY     | Represents a collection of hardware and software pieces and a set of relationships for specific functions.                                                             | Device                                |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Network                | NW     | Represents the structures, products, and services that enable connectivity between system nodes.                                                                       |                                       |                                  |
| Part 1 - Base Elements      | Operational / Infrastructure | Location               | LO     | Represents a place where structural elements are positioned or communicated.                                                                                           |                                       |                                  |
| Part 1 - Base Elements      | General                      | Role                   | RO     | Represents a user, user group, or stakeholder responsible for performing specific behaviors or responsibilities.                                                       | Actor, Stakeholder                    |                                  |
| Part 1 - Base Elements      | General                      | Task                   | TK     | Represents a piece of work assigned to a role within a process.                                                                                                        | Activity, State                       |                                  |
| Part 1 - Base Elements      | General                      | Process                | PS     | Represents a workflow or orchestration of multiple contained services or activities.                                                                                   | Workflow, Composite Service           |                                  |
| Part 1 - Base Elements      | General                      | Domain                 | DM     | Represents a coherent functional boundary within which multiple elements are governed under a common scope.                                                            | Bounded Context, Platform, Zone, etc. |                                  |
| Part 1 - Base Elements      | General                      | Grouping               | GP     | Represents a logical layer, composition, aggregation, or organization of related elements.                                                                             | Group                                 |                                  |
| Part 1 - Base Elements      | General                      | View Frame             | VF     | Represents a model scope, perspective, drill-down view, or solution plateau used to describe architecture at a specific level.                                         | Partial View                          |                                  |
| Part 1 - Base Elements      | General                      | Generic Service        | GS     | Represents a conceptual business or application capability used to describe solution behavior at a high level.                                                         | Conceptual Service                    |                                  |
| Part 1 - Base Elements      | General                      | Virtual Service        | VS     | Represents a non- physical IT service or without a clear interface.                                                                                                    | Configuration, Collaboration          |                                  |
| Part 1 - Base Elements      | General                      | Deliverable (Optional) | DL     | Represents a scoped solution increment with defined outcomes and acceptance criteria, along with its associated resources.                                             |                                       |                                  |
| Part 1 - Base Elements      | General                      | Artifact               | AR     | Represents a tangible work product created during the solution lifecycle.                                                                                              | Tangible Asset, Document              |                                  |
| Part 1 - Base Elements      | General                      | Note                   | NT     | Represents commentary, interpretation, or supplementary information about the architecture.                                                                            | Key Element Properties                |                                  |
| Part 1 - Base Elements      | General                      | Input (Optional)       | IN     | Represents the data, signals, queries, and information consumed by the solution.                                                                                       |                                       |                                  |
| Part 1 - Base Elements      | General                      | Output (Optional)      | OU     | Represents the results, recommendations, and responses produced by the solution.                                                                                       |                                       |                                  |
| Part 1 - Base Elements      | General                      | Extension              | EX     | Represents a flexible for model element addition, including non-IT element.                                                                                            | External system/solution element      |                                  |
| Part 2 - Assistive Elements | Solution Management          | Issue & Constraint     | CS     | Represents the issues, limitations, assumptions, and dependencies that shape and bound the solution space.                                                             | Problem                               | Risk                             |
| Part 2 - Assistive Elements | Solution Management          | Stage                  | ST     | Represents a scoped solution increment or state with defined outcomes and acceptance criteria, along with its associated resources.                                    | Product, Solution Model, View Frame   | Deliverable                      |
| Part 2 - Assistive Elements | Architectural Style          | Frontend               | FE     | Represents the user access channels and mechanisms such as mobile device, browser, PC, etc.                                                                            |                                       | System Device                    |
| Part 2 - Assistive Elements | Architectural Style          | Cloud                  | CL     | Represents on-demand computing capabilities and resources available as a service.                                                                                      |                                       | Domain                           |
| Part 2 - Assistive Elements | Architectural Style          | Microservice           | MS     | Represents a well-defined bounded-context or an independently deployable unit.                                                                                         |                                       | Generic Service, Deployment Unit |
| Part 2 - Assistive Elements | Architectural Style          | Event Service          | ES     | Represents the handling of system state changes and notifications.                                                                                                     |                                       | Tech Service                     |
| Part 2 - Assistive Elements | DevOps                       | Quality Metric         | QM     | Represents a measurable indicator of solution quality, development, or operational effectiveness.                                                                      |                                       | Requirement                      |
| Part 2 - Assistive Elements | DevOps                       | Governance Function    | GF     | Represents rules, design specifications, or nonfunctional requirements that govern architectural characteristics.                                                      |                                       | Governance                       |
| Part 2 - Assistive Elements | DevOps                       | Quality & Adaptation   | QV     | Represents the validation, and continuous improvement mechanisms that assess solution quality and performance.                                                         |                                       | Governance, View Frame           |
| Part 2 - Assistive Elements | DevOps                       | Governance Control     | GO     | Represents operational mechanisms that enforce policies, security, compliance, and oversight.                                                                          | Governance Operation                  | Governance                       |
| Part 2 - Assistive Elements | Software Design              | Object                 | OB     | Represents a distinct, identifiable objects within a software domain                                                                                                   | Entity, Component                     | Service Component                |
| Part 2 - Assistive Elements | Software Design              | Module                 | MO     | Represents a self-contained unit of implementation within a larger application                                                                                         |                                       | Domain                           |
| Part 2 - Assistive Elements | Software Design              | Data File              | TB     | Represents a collective of data intended to be implemented by software applications.                                                                                   | Table, File, Artifact                 | Artifact                         |
| Part 2 - Assistive Elements | Software Design              | Schema                 | SM     | Represents a structure that defines how data is organized and managed in a database.                                                                                   |                                       | Domain                           |
| Part 2 - Assistive Elements | Software Design              | Transaction            | TR     | Represents a sequence of one or more data operations that are treated as a unit to ensure data consistency and integrity.                                              |                                       | Domain                           |
| Part 2 - Assistive Elements | Software Design              | Repository & Library   | RP     | Represents a storage place for software assets, packages, or reusable components.                                                                                      |                                       | Artifact                         |
| Part 2 - Assistive Elements | Integration & Scalability    | Message Service        | MG     | Represents the contracts, events, and messages exchanged between services or components.                                                                               |                                       | Data Service                     |
| Part 2 - Assistive Elements | Integration & Scalability    | Edge & Adapter         | EG     | Represents a component that enables integration between otherwise incompatible systems or interfaces.                                                                  |                                       | Middleware                       |
| Part 2 - Assistive Elements | Integration & Scalability    | Gateway Service        | GW     | Represents a unified access point that manages, secures, and routes service interactions.                                                                              |                                       | Middleware                       |
| Part 2 - Assistive Elements | Integration & Scalability    | Service Broker         | SB     | Represents an intermediary service that coordinates message exchange between loosely coupled components.                                                               |                                       | Middleware                       |
| Part 2 - Assistive Elements | Integration & Scalability    | Cache Service          | CA     | Represents a temporary data store that improves performance through fast data access.                                                                                  |                                       | Data Service                     |
| Part 2 - Assistive Elements | AI-Specific                  | Agent                  | AG     | Represents an autonomous AI entity capable of goal-directed reasoning, planning, and action.                                                                           |                                       | Generic Service, App Logic       |
| Part 2 - Assistive Elements | AI-Specific                  | AI Coordinator         | AC     | Represents the coordination logic, workflow control, and multi-agent management that sequences and routes AI operations.                                               |                                       | Process                          |
| Part 2 - Assistive Elements | AI-Specific                  | Context State          | CN     | Represents the mechanisms for managing conversational state, memory, prompt engineering, and interaction coherence.                                                    |                                       | Data Service                     |
| Part 2 - Assistive Elements | AI-Specific                  | Model & Reasoning      | ML     | Represents the models, inference engines, and reasoning frameworks that generate predictions, decisions, or outputs.                                                   |                                       | Data Service                     |
| Part 2 - Assistive Elements | AI-Specific                  | Knowledge Access       | KA     | Represents the semantic retrieval, embedding, and knowledge management capabilities that ground AI responses in relevant information.                                  |                                       | Data Service                     |
| Part 2 - Assistive Elements | AI-Specific                  | Tool & Action          | TL     | Represents external functions, plugins, and third-party services that extend AI capabilities through invocation.                                                       |                                       | Tech Service                     |
| Part 2 - Assistive Elements | AI-Specific                  | AI/ML Lifecycle        | AL     | Represents the lifecycle management processes for model training, experimentation, versioning, and deployment.                                                         |                                       | Process, Capability              |
| Part 2 - Assistive Elements | Business                     | Product                | PD     | Represents a piece of physical software, equipment and the like offered as a whole.                                                                                    |                                       | Deliverable                      |
| Part 2 - Assistive Elements | Business                     | Value                  | VL     | Represents the relative importance, worth of a concept or vision from an enterprise perspective.                                                                       |                                       | Intent                           |
| Part 2 - Assistive Elements | Infrastructure               | Zone                   | ZN     | Represents a logical segment of a network that groups resources or devices based on policies.                                                                          | Domain                                | Group                            |
| Part 2 - Assistive Elements | Infrastructure               | Tier                   | TE     | Represents a physical group of system elements within an environment such as a located server fleet.                                                                   |                                       | Domain                           |
| Part 2 - Assistive Elements | Infra Add-on                 | Firewall               | FI     | Represents a network security system that monitors and controls traffic based on predefined rules.                                                                     |                                       | Network                          |
| Part 2 - Assistive Elements | Infra Add-on                 | Router & Switch        | RT     | Represents the sharing of resources by connecting together the network devices.                                                                                        | Hub                                   | Network                          |
| Part 2 - Assistive Elements | Infra Add-on                 | Server                 | SR     | Represents a specialized software system designed to manage, and deliver data or services to other devices (clients).                                                  |                                       | Middleware                       |
| Part 2 - Assistive Elements | Infra Add-on                 | Device                 | DV     | Represents a physical hardware capable of receiving, processing, and outputting data.                                                                                  |                                       | System                           |
| Part 2 - Assistive Elements | Infra Add-on                 | Storage                | SE     | Refers to where a computer keeps digital data for later use.                                                                                                           |                                       | Data Store, System Device        |
| Part 2 - Assistive Elements | Infra Add-on                 | Virtual Server         | VE     | Represents a software-based server created by partitioning a physical server into multiple isolated environments.                                                      |                                       | Virtual Service                  |
| Part 2 - Assistive Elements | Infra Add-on                 | Security Threat        | TH     | Represents an action or virus that has the potential to cause damage to information systems, and networks.                                                             |                                       | Risk                             |
| Part 2 - Assistive Elements | Infra Add-on                 | Rack                   | RC     | Represents a standardized metal frame designed to securely house and organize IT equipment.                                                                            |                                       | Extension                        |
| Part 2 - Assistive Elements | Business Add-on              | Function               | BF     | Refers to a group of related activities or tasks in business to achieve an organization's goals and deliver value.                                                     |                                       | Generic Service, Use Case        |
| Part 2 - Assistive Elements | Business Add-on              | Analytics              | AA     | Represents the process or software system to extract meaningful insights and make predictions.                                                                         |                                       | Middleware                       |
| Part 2 - Assistive Elements | Business Add-on              | Activity               | AV     | Refers to any action or process to provide services or generate revenue.                                                                                               |                                       | Task                             |
| Part 2 - Assistive Elements | Business Add-on              | Value Stream           | VP     | Represents the end-to-end sequence of activities to deliver value to a customer or stakeholder.                                                                        |                                       | Value, Process                   |

Each element id represented by a two-letter prefix as the node image value. The script handles the real image mapping.

The choice of elements depends on the user's needs, architectural style(s) or what they implied.

Each architectural style has a set of commonly used elements that form a complete model. For example:

- Enterprise architecture (EA) elements: IT, CP, PR, RQ, KC, DS, TS, SI, SC, AP, ES, BF, OB, MW, ND, SY, NW, LO, RO, TK, PS, GP, DL, AR, NT, OU, ST

- Software architecture (SWA) elements: UC, RQ, KC, UI, AS, DS, TS, SI, SC, AP, DP, DB, ND, SY, RO, TK, GP, AR, NT, QM, GF, OB, MO, DM, SM, TR, RP

- Integration & scalability architecture (IS, a more complex, application-level architecture) elements: CP, UC, PR, RK, RQ, QM, KC, GV, UI, AS, DS, TS, SI, AP, TR, DP, GO, DB, MW, ND, SY, NW, ZN, TE, LO, RO, TK, PS, DM, GP, VF, GS, VS, NT, EX, FE, CL, MS, ES, MG, EG, GW, SB, CA

- And so on, following a similar pattern drawn from practical solutions.

In particular, solution architecture is a common choice for solution architects and software architects, so its elements are listed below for better mapping:

| Category               | Element         | Prefix | Implication                                                         | Base Mapping                           |
| ---------------------- | --------------- | ------ | ------------------------------------------------------------------- | -------------------------------------- |
| Intent/Metrics         | User            | RO     | Stakeholder, Actor                                                  | Role                                   |
| Intent/Metrics         | Task            | TK     | Activity, Event                                                     | Task                                   |
| Intent/Metrics         | Requirement     | RQ     | Intent, Non-functional Requirement                                  | Requirement                            |
| Intent/Metrics         | Decision        | KC     | Key Consideration, Governance                                       | Key Choice                             |
| Intent/Metrics         | Artifact        | AR     | Documentation, Repository, Code                                     | Artifact                               |
| Intent/Metrics         | Service         | GS     | Domain, Use Case, Service Definition                                | Generic Service                        |
| Functional/Application | Application     | AP     | ERP App                                                             | Application                            |
| Functional/Application | AI Agent        | AG     | AI Bot                                                              | Agent                                  |
| Functional/Application | User Interface  | UI     | CLI, UI                                                             | User/Access Interface                  |
| Functional/Application | Process         | PS     | Flow, Lifecycle                                                     | Process                                |
| Functional/Application | App Controller  | AS     | AI Coordinator                                                      | App Logic Service                      |
| Functional/Application | Data Module     | DS     | Knowledge Access                                                    | Data Service                           |
| Functional/Application | AI Model        | ML     | LLM                                                                 | Data Service                           |
| Functional/Application | Context         | CN     | State, Memory                                                       | Data Service                           |
| Functional/Application | API Interface   | SC     |                                                                     | Service Interface                      |
| Functional/Application | Utility Service | TS     | Tool                                                                | Tech Service                           |
| Functional/Application | Component       | SC     | Object, Module                                                      | Service Component                      |
| Functional/Application | Microservice    | MS     | Self-contained Unit                                                 | Deployment Package                     |
| Operational/Middleware | Frontend        | FE     | Mobile Device, PC Device                                            | UI Service, Middleware                 |
| Operational/Middleware | System          | SY     | System Device                                                       | System                                 |
| Operational/Middleware | Database        | DB     | Storage                                                             | Data Store                             |
| Operational/Middleware | Deployment Unit | DP     |                                                                     | Deployment Package                     |
| Operational/Middleware | Node            | ND     | Server                                                              | Node                                   |
| Operational/Middleware | Service Broker  | SB     | Message Broker, Event Broker                                        | Middleware                             |
| Operational/Middleware | Message/Event   | MG     |                                                                     | Data Service, Tech Service, Middleware |
| Operational/Middleware | Monitoring      | GO     | Governance Control, Analytics, Observability,  Quality & Adaptation | Middleware, Governance                 |
| Operational/Middleware | Gateway         | GW     | API Gateway, Router                                                 | Middleware                             |
| Operational/Middleware | Security        | FI     | Security Threat, Virus Preventation Firewall                        | Middleware                             |
| Operational/Middleware | Caching         | CA     | CDN                                                                 | Middleware                             |
| Operational/Middleware | Cloud           | CL     | Cloud Service, Cloud Platform                                       | Domain, Location                       |

### ArchView Area

Each view is composed of elements typical for its solution area. In practice, every element in a view needs to satisfy both the archview element definition and the practical needs of the view's context.

Based on the practical ESA standard, ArchView covers six architecture areas: 1) business (or enterprise capabilities), 2) use-case (significant scenarios), 3) metrics (key quality attributes and governance measures), 4) overall-solution (architecture overview, the most used), 5) functional, and 6) operational.

Note that the metrics area is often a part of the overall solution. ArchView highlights it because it is commonly overlooked in architectural diagrams.

## ArchView Rules

The following rules apply specifically to this data specification, other than the rules specified in the SKILL.md that apply to both this specification and the lean-mode specification.

### Rendering Rules

**Group**

- Rule-G2: DM (domain), LO (location), TE (tier), and VF (view frame) elements are typically shown as solid-line groups, while GP (grouping) and ZN (zone) are typically shown as dotted-line groups. Most elements can be treated as a composition or aggregation, represented by the group box. For example, a role [RO] can be rendered as a group box containing certain tasks the role is responsibile for.

- Rule-G3: Optionally, use color to distinguish the ESA nature of the elements within a group. Not all group colors will be shown in a single view except for the overall-solution view. The group colors include:
  
  - seashell [#FFF5EE] for a business group
  - ivory [#FFFFF0] for a case-scenario group
  - ghostwhite [#F8F8FF] for a metrics group
  - honeydew [#F0FFF0] for a functional group
  - beige [#F5F5DC] for an operational deployment group

- Rule-G6: For an architecture overview (part of the overall-solution view), use more group boxes and fewer or no edges to emphasize high-level building blocks.

- Rule-G7: For integration view, walkthrough/verification view, and similar views (part of the overall-solution view), use fewer group boxes to emphasize flows between nodes.

- Rule-G8: For all views other than the overall-solution view, each view should focus on its own set of elements. For example, the functional view should contain primary functional elements, coupled with key links to other view areas (groups or elements).

**Node**

- Rule-N1: A node's label starts with a two-letter prefix (e.g., SY for system) as defined in archview-elements.md, followed by an index (dash + number), a space, and the title description, for example, SY-11 CRM Application Suite. Adding an index is optional, but it's a common convention for easy correlation.

- Rule-N2: In the properties string, use "=" to separate a property from its attribute, and "|" to separate property=attribute pairs. For example, the properties of the "RQ-5 Solution Requirements" element might read: Requirement 1=Utilize AI image recognition features|Requirement 2=Allow large volume processing.

- Rule-N4: Keep the total node count per view under around 30 if there are multiple edges, or under around 40 if there are few or no edges. For a complex solution, split the view into layers using the view-frame element as a connector between them.

- Rule-N5: Think hard about the base/foundational elements such as UI, AS, DS, and TS to see where they will be deployed, how they adapt to change, and who will be responsible for them.

- Rule-N6: For specific architectural styles, use the assistive elements in the spec (for example, an AI architecture will lean more heavily on AI-specific elements). Since ESA elements apply across different solution architectures, choose whichever fits the view's context best.

- Rule-N7: The "add-on" assistive elements in the spec are mainly used in business architecture or infrastructure architecture. They typically map back to their corresponding base elements in ESA, to help simplify complex solutions.

- Rule-N9: For focused architectural thinking at an ESA level, use base elements to balance layering, coupling, granularity, and isolation more intuitively. Map assistive elements, if any, to their base ones, such as assistive GW (Gateway) mapping to its base MW (Middleware).

- Rule-N10: For overall-solution considerations, there are likely many element types, but for more focused views (capability, metrics, functional, operational, etc.), there are more element instances (such as CP-1, CP-2, CP-3...) than base types.

- Rule-N13: The *extension* element is rarely used in general solutions and is reserved for things like IoT (Internet of Things), OT (operational technology), robots, equipment, etc. In many cases, you can use the *system* element instead.

**Edge (Link)**

- Rule-E2: For an edge that denotes composition, use the "arrow" type with a label like "composition," or set the composed node as part of a group instead.
