---
name: archview
description: Generate IT architecture diagrams and model views in a node-image style, primarily at the enterprise solution architecture (ESA) level, between enterprise architecture and solution design. Use this skill for requests like "draw an architecture diagram," "create a solution architecture view," "visualize this system's architecture," or "show the components and how they connect," even when the user doesn't name ArchView directly. Fits large or complex solutions needing clear, maintainable views; requests for a simple, systematic set of architectural elements; or any IT view built from node images, spanning business, use-case, functional, operational, metrics, or overall-solution perspectives. Do NOT use for digital-twin-style, code-level reverse engineering, or detailed design diagrams (other tools handle those better), or rough sketches that do not need a well-framed, spec-based representation. Produces self-contained HTML output (zoom, export, PDF report, view properties) tailored to different stakeholders.
license: MIT
version: 1.0.14
author: seangu@a-esa.com

---

# ArchView Skill

## File Structure

archview/
    assets/
        archview.json
        archview.html (output file)
    references/
         archview-elements.md
        archview-output-sample.html
        archview-input-sample.json
        archview-report-sample.pdf
    scripts/
        create-archview.js
    LICENSE.txt    
    SKILL.md

Note that the scripts directory contains several files, including dagre.min.js, graph.js, page.js, render.js, etc. They are safe to run, and you don't need to access them.

## Usage Scenarios

### Prerequisites

- The user is interested in architecture, or works in an architect role.
- The intended view(s) aren't too broad in scope (e.g., strategic planning, enterprise architecture, or solution management), and aren't detailed design or mere technical diagrams either.
- The final output is more than a diagram or sketch view (sketches are fine for early iterations); it should carry clear metrics or architectural significance. ArchView is best suited to architectural granularity reasoning, metric mapping, and end-to-end validation.
- Each view belongs to one of the areas or categories defined in the ArchView area list. A typical ESA model includes a business view (enterprise capabilities), plus use-case (solution-focused case scenarios), metrics, functional, operational, and overall-solution views. The solution views cover a system of systems or an integrated system. A single-view approach works well for simple solution ideas or quick verification.

### Leading Role

- **User-led**: The user already has a draft set of architectural ideas, documents, or diagrams and is well-versed in IT or solution architecture. The goal is a well-architected, simple yet systematic model.

- **AI-led**: The user wants architectural guidance from AI, based on typical requirements, patterns, or leading practices.

- **AI-human collaboration** (the most common): Both sides contribute, AI brings its knowledge base and reasoning, the human brings domain expertise and judgment, and together they work through edge cases and value considerations.

### View Type

- **Simple view**: The user just wants one or two views to clarify a particular solution architecture.

- **End-to-end scenario view**: The user wants a typical or significant walk-through view that validates a solution.

- **Holistic view**: The user wants a full enterprise solution architecture model spanning business and capability through to architectural realization.

### User's Know-how

- For **novice users**, use self-explanatory elements and simplify the architectural concepts.

- For **specialists**, use elements suited to their specialization (for example, AI-specific elements for AI designers/developers, or business elements for CxOs and analysts).

- For **architects**, use a foundational set of elements plus assistive elements that support deeper exploration of architectural techniques and issues.

## ArchView Interaction Process

- Identify the usage scenario based on the query and user's input.
- Gather the relevant architectural background: issues, pain points, and solution or exploration needs. For existing solutions, capture the as-is environment. Draw on the user's knowledge of stakeholders, objectives, constraints, and the solution's key services or interfaces.
- Research comparable, successful human-led solutions or suitable patterns via web search or model's internal knowledge access about the leading practices and industry benchmarks, pitfalls, alternatives, decision points, and success criteria related to the requested solution.
- Based on user's input and your findings, work out the view area and the key architectural element mapping according to the ArchView element list and area defined in the *ArchView Specification* section.
- Prepare and process the input data (ViewInfo and Graph data) per the Data Asset Specification.
- Run create-archview.js to produce the output view, archview.html.
- If the user is satisfied, you're done. Otherwise, refine the view based on the user's feedback or new findings, iterating as needed.
- Optionally, produce a revised view or additional views until the user is satisfied. For complex solutions, start simple and iterate, focusing on one or two areas per view, as an architectural thinking and clarification process, before finalizing the ArchView.

## ArchView Data Asset Specification

ArchView (also referred to as "the archview") is generated solely from the input file ***archview.json*** (containing ViewInfo data, Graph image data, and Properties data) in the assets directory. Here is the structure of archview.json:

```
{
"viewInfo":[
{
"Title": "Title info",
"Description": "<p>Brief summary</p>",
"Area": "Overall-solution",
"Status": "Testing Stage",
"Implication": "<p>The complete model needs also to consider the following views:</p><p><b>Capability View</b> (an overview) - Focusing on ABC </p>"
}
],
  "groups": [
    {
      "id": "g1",
      "label": "g1 title",
      "style": "solid",
      "gcolor": ""
    },
    {
      "id": "g2",
      "label": "g2 title",
      "style": "line",
      "gcolor": "beige"
    }
  ],
  "nodes": [
    {
      "id": "n1",
      "group": "g1",
      "image": "AA",
      "label": "n1 title",
"properties": "property1=attribute1|property2=attribute2"
    },
    {
      "id": "n2",
      "group": "g1",
      "image": "AA",
      "label": "n2 title",
      "properties": ""
    }
  ],
  "edges": [
    {
      "id": "e1",
      "source": "n1",
      "target": "n2",
      "type": "arrow",
      "label": "link e1",
      "link": ""
    },
    {
      "id": "e2",
      "source": "g1",
      "target": "g2",
      "type": "arrow",
      "label": "link e2",
      "link": "group"
    }
  ]
}
```

### ViewInfo data

ViewInfo data includes the required View Title and View Area, plus View Description, Status, and Implication. Every view should include at least a brief summary; for a complete ArchView model, write out all the listed items in the view description concisely, with relevant content.

1. **Title**: Keep it short and clearly indicative of the view. It can include the project name, the view's key idea, a pattern name, and so on.
2. **Area**: Must be one of: Business, Use-case, Metrics, Overall-solution, Functional, or Operational. "Overall-solution" covers architecture overview or building-block views, solution capability views, DevOps, end-to-end (walk-through) verification, integration or cross-cutting views, and/or pattern views. "Functional" covers high-level application design views, application/technical relationship views, AI (autonomous intelligence) views, and data relationship views. "Operational" covers deployment and infrastructure views.
3. **Description**: Use simple HTML (`<p>` and `<b>`) and give a brief summary of the architectural focus for the given area, the architectural mapping process and actions taken, and, optionally, any metrics, trade-offs, or techniques implied by the view image or property list. For example:
   - **Significant requirements and metrics**: 1) the key stated and implicit requirements (up to 3), 2) the quality attributes being measured (both feasible and realizable), and 3) optionally, potential heat-maps (enterprise/business) or hotspots (solutions), or simply a checklist covering performance (stress simulation, throughput/bandwidth, storage capacity), availability (redundancy, throttling, degrading, rollback), security (digital control, firewall, cloud workload), maintainability (changeability, monitoring, tracing), and cost (ROI, resource utilization). Note the governance measures, scalable action points, or elastic platform choices, and how they show up in the views.
   - **Concrete governance actions**: governance functions within the application, governance controls at runtime, and human oversight where needed.
   - **Architectural techniques**: layering and partitioning, including the applicable principles, patterns, assets, or styles (e.g., cloud architecture, microservice architecture, integration architecture, AI architecture, application architecture or design, infrastructure architecture, business architecture, enterprise architecture, or a mixed style), and why they were chosen.
   - **Key trade-offs**: the significant trade-offs (1–3) considered in the view, or how the view's elements map to the requirements, stated concisely.
4. **Status**: Indicate whether this is a one-time model/view, what stage it's at or a confidence indicator (Draft, Stakeholder-Reviewed, Governance-of-Record), any role assignments, and optionally the degree of readiness, and so on.
5. **Implication**: State assumptions, relevance, further enhancements, recommendations, or action items, in particular how this view relates to others, if any, and what other views are needed to complete an ArchView model for the solution, per the ArchView specification of elements and view areas. State the part you are unsure of, if any. For large, complex enterprise-level solutions, reaching stakeholder agreement (from both business and technical viewpoints) on the model views through iteration is critical.
6. **Timestamp**: Note the date and time for version reference.

Also use the description to explain or clarify architectural-level terms, such as domain, generic service, context state, view frame, and virtual service, to see how they are applied to the solution's context.

The view description is optional, depending on the view's complexity and the user's needs. Its essence should already be reflected in the view itself: a good architectural view, or set of views, should be mostly self-explanatory. A validated model should be agreed on by all identified stakeholders of the architecture.

Note: if the view description is left blank, the output contains only the view graph image, without the PDF report or properties menu options.

### View Graph Data

ArchView graph data follows the format in the table below and the rules in the References section of this document.

Note that a node's prefix determines its architectural characteristics and mappings. That said, each node's title (or label) should still carry a meaningful architectural description suited to the user's level of understanding.

| Item  | Attribute  | Description                       | Usage Example                                                                                                                  |
| ----- | ---------- | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| group | id         | unique group id                   | First letter "g" + auto index, i.e., g1                                                                                        |
| group | label      | group's title                     |                                                                                                                                |
| group | style      | border style                      | solid \| dotted. See rules: Rule-G1 and Rule-G2                                                                                |
| group | gcolor     | group-box's background color      | "white" as default for the generic or cross-cutting group. See Rule-G3.                                                        |
| node  | id         | unique node id                    | First letter "n" + auto index, i.e., n1                                                                                        |
| node  | group      | the group id the node belongs to  |                                                                                                                                |
| node  | image      | node's image prefix               | A two-letter code corresponding to its prefix in the ESA element specification [archview-elements.md]                          |
| node  | label      | node's/image's title              | Follows the Rule-N1 naming convention. The title wraps automatically, but Rule-N3 gives suggested length limits.               |
| node  | properties | element property list (optional)  | A concatenated string of property=attribute pairs, grouped by \| as specified in Rule-N2                                       |
| edge  | id         | unique edge id                    | First letter "e" + auto index, i.e., e1                                                                                        |
| edge  | source     | the id of the link's start node   |                                                                                                                                |
| edge  | target     | the id of the link's end node     |                                                                                                                                |
| edge  | type       | the edge/link's end pointer style | arrow \| line                                                                                                                  |
| edge  | label      | the link title                    | Keep it very short: an action verb or protocol name.                                                                           |
| edge  | link       | the type of element being linked  | "group" for a link between two group-boxes; "" (default) for a link between two nodes. See also Rule-E1, Rule-E2, and Rule-E3. |

### Properties Data

Element properties are part of view graph data. The element property list is optional, but required when elements contain long text and/or additional property attributes that don't fit in the graph view. For a complex view, keep node labels/titles short, and describe the details as a list of property/attribute pairs for the elements that need it. 

### Element Prefix Notation Info

If the view's description input is not blank, the output html will include a list of elements on the view in terms of their spelled-out names, ESA bearing or relevance and belonging category. The prefix notation information will be handled automatically from the code.

## ArchView Output

The output is a self-contained, single-page HTML file that includes a generated SVG image and the view info, with these menu options: zoom (also available via mouse wheel), save as image, copy to clipboard, save as JSON (for record-keeping and further chat context), save as a PDF report (containing both the ArchView image and view info), toggle between the view and its properties, and toggle between Move mode, for customizing the layout, and Zoom mode.

## ArchView Samples

See the following input and output samples in the references directory:

- *archview-input-sample.json*
- *archview-output-sample.html* 

# ArchView References

## ArchView Specification

### ArchView Element List

Each view element is defined in ***archview-elements.md***, located in the *references* directory, and represented by a two-letter prefix as the node image value. The script handles the real image mapping.

The choice of elements depends on the solution's needs and architectural style(s). Each architectural style has a set of commonly used elements that form a complete model. For example:

- Enterprise architecture (EA) elements: IT, CP, PR, RQ, KC, DS, TS, SI, SC, AP, ES, BF, OB, MW, ND, SY, NW, LO, RO, TK, PS, GP, DL, AR, NT, OU, ST

- Software architecture (SWA) elements: UC, RQ, KC, UI, AS, DS, TS, SI, SC, AP, DP, DB, ND, SY, RO, TK, GP, AR, NT, QM, GF, OB, MO, DM, SM, TR, RP

- Integration & scalability architecture (IS, a more complex, application-level architecture) elements: CP, UC, PR, RK, RQ, QM, KC, GV, UI, AS, DS, TS, SI, AP, TR, DP, GO, DB, MW, ND, SY, NW, ZN, TE, LO, RO, TK, PS, DM, GP, VF, GS, VS, NT, EX, FE, CL, MS, ES, MG, EG, GW, SB, CA

- And so on, following a similar pattern drawn from practical solutions.

Each view is composed of elements typical for its solution area. In practice, every element in a view needs to satisfy both the archview-elements.md definition and the practical needs of the view's context.

### ArchView Area

Based on the practical ESA standard, ArchView covers six architecture areas: 1) business (or enterprise capabilities), 2) use-case (significant scenarios), 3) metrics (key quality attributes and governance measures), 4) overall-solution (architecture overview, the most used), 5) functional, and 6) operational.

Note that the metrics area is often a part of the overall solution. Archview highlights it because it is commonly overlooked in architectural diagrams.

## ArchView Principle and Rules

### S3 Principle

ArchView follows ESA's S3 principle: simple, significant, and systematic.

- **Simple**: node-image representation, with a simplified element set adapted to each view.
- **Significant**: critical case scenarios and trade-off considerations via metric mapping.
- **Systematic**: coverage from business to operational, capturing both structural and decisional correlation.

The ArchView model represents complex solutions in a simplified way, focusing only on the cases that matter for systematic thinking. This skill is meant to strengthen architectural thinking, not just to render a view for its own sake.

### General Rules

- Rule-R1: All names and values in archview.json follow the JSON standard and use double quotation marks. Otherwise, the syntax error will be shown.
- Rule-R2: Avoid escape characters such as \n and `` ` `` to prevent breaking the text just in case.
- Rule-R3: Where view info needs HTML, use simple syntax such as `<p></p>` and `<b></b>`.
- Rule-R4: Nodes, groups, and edges in the JSON should not include any HTML syntax.
- Rule-R5: Represent interaction or sequence diagrams as high-level relationship views.
- Rule-R6: Represent workflow or process views through the connection relationships between elements. For business processes, use role or user as the grouping and task/activity as the element, to keep swim-lane and flow representations simple.
- Rule-R7: For capability models or organization views, simulate a tree-view-like structure at a high level.
- Rule-R8: For architecture decision records (ADRs) or other tabular info, include them as part of the element properties or the view description.
- Rule-N9: Don't mention specific rule names here (such as Rule-N1, Rule-G4, etc.) in the output. If need be, for a architectural guidance rule, explain it in simple terms.
- Rule-N10: Don't use specific tool terms like "plateau" (use an ESA term *stage* or something easy to understand instead).

### Rendering Rules

**Group**

- Rule-G1: A group box has either a "solid" or "dotted" border. Solid indicates a domain, tier, or physical isolation; dotted indicates a grouping, or a logical/conceptual group.
- Rule-G2: DM (domain), LO (location), TE (tier), and VF (view frame) elements are typically shown as solid-line groups, while GP (grouping) and ZN (zone) are typically shown as dotted-line groups. Most elements can be treated as a composition or aggregation, represented by the group box. For example, a role [RO] can be rendered as a group box containing certain tasks the role is responsibile for.
- Rule-G3: Optionally, use color to distinguish the ESA nature of the elements within a group. Not all group colors will be shown in a single view except for the overall-solution view. The group colors include:
  - seashell [#FFF5EE] for a business group
  - ivory [#FFFFF0] for a case-scenario group
  - ghostwhite [#F8F8FF] for a metrics group
  - honeydew [#F0FFF0] for a functional group
  - beige [#F5F5DC] for an operational deployment group
- Rule-G4: A group box must contain at least one node element. 
- Rule-G5: As a general grouping rule, consider only a few edge links between nodes in different groups, except for exhibiting an as-is architecture. If edge complexity is high, justify it in the description and show how to improve it (e.g., microservice approach, gateway interface, etc.).
- Rule-G6: For an architecture overview (part of the overall-solution view), use more group boxes and fewer or no edges to emphasize high-level building blocks.  
- Rule-G7: For integration view, walkthrough/verification view, and similar views (part of the overall-solution view), use fewer group boxes to emphasize flows between nodes.
- Rule-G8: For all views other than the overall-solution view, each view should focus on its own set of elements. For example, the functional view should contain primary functional elements, coupled with key links to other view areas (groups or elements).

**Node**

- Rule-N1: A node's label starts with a two-letter prefix (e.g., SY for system) as defined in archview-elements.md, followed by an index (dash + number), a space, and the title description, for example, SY-11 CRM Application Suite. Adding an index is optional, but it's a common convention for easy correlation.
- Rule-N2: In the properties string, use "=" to separate a property from its attribute, and "|" to separate property=attribute pairs. For example, the properties of the "RQ-5 Solution Requirements" element might read: Requirement 1=Utilize AI image recognition features|Requirement 2=Allow large volume processing.
- Rule-N3: Keep node labels concise: ideally under 90 characters or 13 words, and no more than 150 characters or 20 words.
- Rule-N4: Keep the total node count per view under around 30 if there are multiple edges, or under around 40 if there are few or no edges. For a complex solution, split the view into layers using the view-frame element as a connector between them.
- Rule-N5: Think hard about the base/foundational elements such as UI, AS, DS, and TS to see where they will be deployed, how they adapt to change, and who will be responsible for them.
- Rule-N6: For specific architectural styles, use the assistive elements in the spec (for example, an AI architecture will lean more heavily on AI-specific elements). Since ESA elements apply across different solution architectures, choose whichever fits the view's context best.
- Rule-N7: The "add-on" assistive elements in the spec are mainly used in business architecture or infrastructure architecture. They typically map back to their corresponding base elements in ESA, to help simplify complex solutions.
- Rule-N8: For simple cases, agile design thinking, or users who prefer a simpler element set, use the lean-mode elements, which convey ideas more *loosely* than their original definitions. The lean-mode set typically includes: RQ (intent/requirement), KC (decision/governance), GS (application/service), SC (component/object), DB (DB/storage), MW (dev, system, platform software), ND (deployment/node), SY (system/device), RO (user/role), TK (task/activity), GP (grouping/domain), and NT (note/artifact). Together, they cover the key aspects of the ESA model.
- Rule-N9: For focused architectural thinking at an ESA level, use base elements to balance layering, coupling, granularity, and isolation more intuitively. Map assistive elements, if any, to their base ones, such as assistive GW mapping to its base MW.
- Rule-N10: For overall-solution considerations, there are likely many element types, but for more focused views (capability, metrics, functional, operational, etc.), there are more element instances (such as CP-1, CP-2, CP-3...) than base types.
- Rule-N11: Use your best judgment; do the element mapping based on the common solution practices and solution context, not merely on its name per se. For example, a service provider can be a role, a system, or an interface.
- Rule-N12: If you specify an image name that does not exist in the element specification, the element will default to the GS (service). 
- Rule-N13: The *extension* element is rarely used in general solutions and is reserved for things like IoT (Internet of Things), OT (operational technology), robots, equipment, etc. In many cases, you can use the *system* element instead.

**Edge (Link)**

- Rule-E1: For edges with bilateral pointers, use the "line" type (association relationship).
- Rule-E2: For an edge that denotes composition, use the "arrow" type with a label like "composition," or set the composed node as part of a group instead.
- Rule-E3: An edge should only connect between two groups or two nodes, **never** directly between a node and a group.

# ArchView Execution

Generating the ArchView output file requires Node.js. Tested Node.js versions include: v18.20.8, v22.23.2, v24.18.0, and v26.7.0. No dependency modules are needed.

Run the code (archview/scripts/create-archview.js) from the skill's scripts directory as shown in the following command. By default, archview.html is generated in the archview's assets directory.

```
# cd scripts
# node create-archview.js
```

The console log will show the output file's location. If you need more than one view or a preferred file name, you may need the optional command parameters.

Optionally, you can specify your own input file path (JSON file location) as shown in the following. In this case, the output file will have the same name as the JSON file, with the html extension, and will be generated in the default *assets* directory.

```
# node create-archview.js input-file-path
```

You can also optionally specify both the input file name and output directory, as shown in the following command. The generated output file will go to the specified directory.

```
# node create-archview.js input-file-path output-directory
```

For archview.html that opens within the AI's sandbox, the sandboxed iframe likely needs the "allow-downloads" permission. This won't be an issue outside the AI sandbox.

# Appendix

## Scope Guidance by Request Type

Use this to decide how to handle common but non-obvious requests:

| If the user asks for...                                                           | Do this                                                                                                                                                                                                                                                                                                                                                 |
| --------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| An architecture diagram/view based on their own attached information              | Build the view using ArchView elements as normal. If the input is missing key info, note what's missing in the output rather than guessing. ArchView applies to most requests for architecture views or diagrams.                                                                                                                                       |
| An enterprise architecture (EA) diagram from provided info and your own knowledge | Build an architectural mapping view between EA building blocks and solution architecture (SA) building blocks. Include an overview of capabilities, groups, and layers using a system-of-systems approach. Define a small set of guiding architectural principles, and clarify the governance and intent elements. Use the EA element set listed above. |
| A software architecture for their solution design                                 | For UML-level designers, use this simplified set: UC, SI, SC, OB, DP, ND, SY, RO, TK, GP, AR, NT. For a fuller software architecture, use the full SWA element set from the ArchView Element List.                                                                                                                                                      |
| A simple diagram containing "all the elements they listed"                        | Don't take this literally. Use just GP, RO, SY, SC (roles, systems, elements, and boundaries), which is what users (typically developers) usually mean. Alternatively, use the lean-mode element set if they want a simple ESA view.                                                                                                                    |
| A box-and-line diagram with all their listed elements                             | Decline. This isn't what ArchView is for. The user likely wants shape-based elements focused on text description, which falls outside this skill's scope.                                                                                                                                                                                               |
| A Microsoft cloud platform architecture                                           | Clarify or infer which they mean. Option 1, a technical platform diagram with *vendor-specific* *product icons* showing how the cloud products relate to each other: decline, this is out of scope. Option 2, an ESA-style platform architecture built from middleware-centric elements (MW, GW, ES, DB, GO, CL, MS, MG, SB, CA, etc.): build this one. |
| Interaction diagrams (event interactions, LLM process flow, AI lifecycle, etc.)   | Clarify or infer which they mean. Option 1, detailed process/flow-level diagrams: decline, out of scope. Option 2, a high-level summary of interactions: build this as a relationship view instead.                                                                                                                                                     |
| A class diagram for their solution design                                         | Decline. ArchView doesn't produce detailed-design-level diagrams.                                                                                                                                                                                                                                                                                       |

## Intended Restrictions

Here are the intended restrictions, for architectural clarity and conformance:

- **View style is restricted to node-image representation only.** It doesn't render other diagram types such as formal process (e.g., BPMN) views, organization views, tree views, interaction views, class diagrams, matrix/table views, mind maps, and so on. This is *intentional*, to keep the architecture view simple and purposeful. All of these diagram types can still be elevated to an architectural level to support proper representation.
- **The view is restricted to the elements within the specification.** This preserves architectural conformance and avoids inconsistent levels of granularity or representation. The elements focus on enterprise solution architecture (spanning business, application, data, and technical domains) while also reflecting transitional elements from enterprise architecture and solution design. For special edge case elements, you can map to *generic service*, *component*, *system*, or whichever has a closer architectural resemblance. Or you can use the *extension* element if it's remotely related to the solution, such as a facility.
- **There's a maximum node count, to avoid excessive complexity.** For a very complex solution, choose an appropriate level of abstraction and use layering/partitioning elements (grouping, domain, view frame) for clear architectural mapping.

## Tool Limitations and Resolutions

The current tool version has some limitations:

- **Because of the auto-layout, elements in the output view may not appear in the expected order or position.** However, users can customize the layout by moving groups or nodes to their desired positions in the generated HTML page, improving the layering order and overall visual presentation.
- **Each output HTML represents only one area view of the model.** A single HTML output serves simple solution-overview needs. For a fuller model-level mapping, correlate the output views across multiple HTML files. You can check the related archview.json or data.json files (which the user can export as a history record or context) to validate the overall relationships.

## Link of the Skill Download

- https://github.com/archview/skill
