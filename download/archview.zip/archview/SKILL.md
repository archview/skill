---
name: archview
description: Generate IT architecture diagrams and model views in a node-image style, primarily at the enterprise solution architecture (ESA) level, between enterprise architecture and solution design. Use this skill for requests like "draw an architecture diagram," "create a solution architecture view," "visualize this system's architecture," or "show the components and how they connect," even when the user doesn't name ArchView directly. Fits large or complex solutions needing clear, maintainable views; requests for a simple, systematic set of architectural elements; or any IT view built from node images, spanning lean-mode （by default), business, use-case, functional, operational, metrics, or overall-solution perspectives. Do NOT use for digital-twin-style, code-level reverse engineering, or detailed design diagrams (other tools handle those better). Produces self-contained HTML output (zoom, export, PDF report, view properties) tailored to different stakeholders.
license: MIT
version: 1.0.15
author: seangu@a-esa.com

---

# ArchView Skill

## File Structure

archview/
    assets/
        archview.json
        archview.html (output file)
    references/
        archview-data-specification.md
        archview-data-specification-lean-mode.md
        archview-lean-mode-image-sample.png
        archview-lean-mode-output-sample.html
        archview-lean-mode-report-sample.pdf
        archview-sample-input.json
        archview-sample-output.html
        archview-sample-report.pdf
    scripts/
        create-archview.js
    LICENSE.txt    
    SKILL.md

Note that the scripts directory contains several files, including dagre.min.js, graph.js, page.js, render.js, etc. They are safe to run, and you don't need to access them.

## Usage Scenarios

### Prerequisites

- The user is interested in IT architecture, or works in an architect role.
- The intended view(s) aren't too broad in scope (e.g., strategic planning, enterprise architecture, or solution management), and aren't detailed design or mere technical diagrams either.
- The final output is more than a diagram or sketch view (sketches are fine for early iterations); it should carry clear mapping or architectural significance. ArchView is best suited to architectural granularity reasoning, metric mapping, and end-to-end validation.
- Other than the lean-mode view, each view belongs to one of the areas or categories defined in the ArchView area list. A full ESA model includes a business view (enterprise capabilities), plus use-case (solution-focused case scenarios), metrics, functional, operational, and overall-solution views. The solution views cover a system of systems or an integrated system. A single-view approach works well for simple solution ideas or quick verification.

### Leading Role

- **User-led**: The user already has a draft set of architectural ideas, documents, or diagrams and is well-versed in IT or solution architecture. The goal is a well-architected, simple yet systematic model.

- **AI-led**: The user wants architectural guidance from AI, based on typical requirements, patterns, or leading practices.

- **AI-human collaboration** (the most common): Both sides contribute, AI brings its knowledge base and reasoning, the human brings domain expertise and judgment, and together they work through edge cases and value considerations.

### View Type

- **Simple view**: The user just wants one or two views to clarify a particular solution architecture.

- **End-to-end scenario view**: The user wants a typical or significant walk-through view that validates a solution.

- **Holistic view**: The user wants a full enterprise solution architecture model spanning business and capability through to architectural realization.

### User's Know-how

- For **novice users**, use self-explanatory or lean-mode elements and simplify the architectural concepts.

- For **specialists**, use elements suited to their specialization (for example, AI-specific elements for AI designers/developers, or business elements for CxOs and analysts).

- For **experienced architects**, use a foundational set of elements plus assistive elements that support deeper exploration of architectural techniques and issues.

## ArchView Interaction, a Leading Practice Process

- Identify the usage scenario based on the query and user's input.
- Gather the relevant architectural background: issues, pain points, and solution or exploration needs. For existing solutions, capture the as-is environment. Draw on the user's knowledge of stakeholders, objectives, constraints, and the solution's key services or interfaces.
- Research comparable, successful human-led solutions or suitable patterns via web search or model's internal knowledge access about the leading practices and industry benchmarks, pitfalls, alternatives, decision points, and success criteria related to the requested solution.
- Based on user's input and your findings, work out the view area and the key architectural element mapping according to the ArchView element list and area defined in the *ArchView Specification* section.
- Prepare and process the input data (ViewInfo and Graph data) per the Input Data Specification.
- Run create-archview.js to produce the output view, archview.html.
- If the user is satisfied, you're done. Otherwise, refine the view based on the user's feedback or new findings, iterating as needed.
- Optionally, produce a revised view or additional views until the user is satisfied. For complex solutions, start simple and iterate, focusing on one or two areas per view, as an architectural thinking and clarification process, before finalizing the ArchView.

## ArchView Data Specification

This is the core section of ArchView. There are two data specification, but you must use only one based on the following criteria:

- Use **archview-data-specification-lean-mode.md** (located in the `references` directory) for simple solutions, agile design workflows, or users who prefer a streamlined element set. This is the **default view** for first-time users or when the user's architectural proficiency is unknown. This lean mode is ideal for developers and junior architects who require simplified architectural diagrams.

- Use **archview-data-specification.md** (located in the `references` directory) for seasoned architects, advanced architectural thinkers, or users highly interested in architectural tradeoffs. This model provides a comprehensive, formal approach with defined metric properties and governance mechanisms. Its ability to build a holistic model covering all key areas of a typical solution architecture makes it ideal for deep, complex design thinking. Note: Due to its advanced nature, this view is not suitable for general users, developers, or projects requiring quick, simple solutions

The rest part of this SKILL.md applies to both specifications. 

## ArchView Rules

### General Rules

- Rule-R1: All names and values in archview.json follow the JSON standard and use double quotation marks. Otherwise, the syntax error will be shown.
- Rule-R2: Avoid escape characters such as \n and `` ` `` to prevent breaking the text just in case.
- Rule-R3: Where view info needs HTML, use simple syntax such as `<p></p>` and `<b></b>`.
- Rule-R4: Nodes, groups, and edges in the JSON should not include any HTML syntax.
- Rule-R5: Represent interaction or sequence diagrams as high-level relationship views.
- Rule-R6: Represent workflow or process views through the connection relationships between elements. For business processes, use role or user as the grouping and task/activity as the element, to keep swim-lane and flow representations simple.
- Rule-R7: For capability models or organization views, simulate a tree-view-like structure at a high level.
- Rule-R8: For architecture decision records (ADRs) or other tabular info, include them as part of the element properties or the view description (for the lean-mode).
- Rule-N9: Don't mention specific rule names here (such as Rule-N1, Rule-G4, etc.) in the output. If need be, for a architectural guidance rule, explain it in simple terms.
- Rule-N10: Don't use specific tool terms like "plateau" (use an ESA term *stage* or something easy to understand instead).

### Rendering Rules

**Group**

- Rule-G1: A group box has either a "solid" or "dotted" border. Solid indicates a domain, tier, or physical isolation; dotted indicates a grouping, or a logical/conceptual group.

- Rule-G4: A group box must contain at least one node element.

- Rule-G5: As a general grouping rule, consider only a few edge links between nodes in different groups, except for exhibiting an as-is architecture. If edge complexity is high, justify it in the description and show how to improve it (e.g., microservice approach, gateway interface, etc.).

**Node**

- Rule-N3: Keep node labels concise: ideally under 90 characters or 13 words, and no more than 150 characters or 20 words.

- Rule-N11: Use your best judgment; do the element mapping based on the common solution practices and solution context, not merely on its name per se. For example, a *service provider* can be a role, a system, or an interface.

- Rule-N12: If you specify an image name that does not exist in the element specification, the element will default to the GS (service) in the code.

**Edge (Link)**

- Rule-E1: For edges with bilateral pointers, use the "line" type (association relationship).

- Rule-E3: An edge should only connect between two groups or two nodes, **never** directly between a node and a group.

# ArchView Execution

Generating the ArchView output file requires Node.js. Tested Node.js versions include: v18.20.8, v22.23.2, v24.18.0, and v26.7.0. No dependency modules are needed.

Run the code (archview/scripts/create-archview.js) from the skill's scripts directory as shown in the following command. By default, archview.html is generated in the archview's assets directory.

```
# cd scripts
# node create-archview.js
```

The console log will show the output file's location. If you need more than one view or a preferred file name, you may need the optional command parameters.

Optionally, you can specify your own input file path (JSON file location) as shown in the following. In this case, the output file will have the same name as the JSON file, with the html extension, and will be generated in the default *assets* directory.

```
# node create-archview.js input-file-path
```

You can also optionally specify both the input file name and output directory, as shown in the following command. The generated output file will go to the specified directory.

```
# node create-archview.js input-file-path output-directory
```

For archview.html that opens within the AI's sandbox, the sandboxed iframe likely needs the "allow-downloads" permission. This won't be an issue outside the AI sandbox.

# Appendix

## ArchView Principle

ArchView follows ESA's **S3 principle:** simple, significant, and systematic.

- **Simple**: node-image representation, with a simplified element set adapted to each view.
- **Significant**: critical case scenarios and trade-off considerations via metric mapping.
- **Systematic**: coverage from business to operational, capturing both structural and decisional correlation.

The ArchView model represents complex solutions in a simplified way, focusing only on the cases that matter for systematic thinking. This skill is meant to strengthen architectural thinking, not just to render a view for its own sake.

## Scope Guidance by Request Type

Use this to decide how to handle common but non-obvious requests:

| If the user asks for...                                                           | Do this                                                                                                                                                                                                                                                                                                                                                                                    |
| --------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| An architecture diagram/view based on their own attached information              | Build the view using ArchView elements as normal, considering the lean-mode view by default. If the input is missing key info, note what's missing in the output rather than guessing. ArchView applies to most requests for architecture views or diagrams.                                                                                                                               |
| An enterprise architecture (EA) diagram from provided info and your own knowledge | Build an architectural mapping view between EA building blocks and solution architecture (SA) building blocks. Include an overview of capabilities, groups, and layers using a system-of-systems approach. Define a small set of guiding architectural principles, and clarify the governance and intent elements. Use the EA element set specified in the archview-data-specification.md. |
| A software architecture for their solution design                                 | For UML-level designers, use this simplified set: UC, SI, SC, OB, DP, ND, SY, RO, TK, GP, AR, NT. For a fuller software architecture, use the full SWA element set from the ArchView Element List in the archview-data-specification.md. Or use the lean-mode elements in the archview-data-specification-lean-mode.md, if a less detailed view and description is preferred.              |
| A simple diagram containing "all the elements they listed"                        | Don't take this literally. Use the lean-mode element set if they want a simple ESA view. Alternatively, use just a subset of the lean-mode elements: RO, SY, SC, and GP (roles, systems, components, and boundaries), which is what users (typically developers) usually mean for a minimal set of elements.                                                                               |
| A box-and-line diagram with all their listed elements                             | Decline. This isn't what ArchView is for. The user likely wants shape-based elements focused on text description, which falls outside this skill's scope.                                                                                                                                                                                                                                  |
| A Microsoft cloud platform architecture or the like                               | Clarify or infer which they mean. Option 1, a technical platform diagram with *vendor-specific* *product icons* showing how the cloud products relate to each other: decline, this is out of scope. Option 2, an ESA-style platform architecture built from middleware-centric elements (MW, GW, ES, DB, GO, CL, MS, MG, SB, CA, etc.): build this one.                                    |
| Interaction diagrams (event interactions, LLM process flow, AI lifecycle, etc.)   | Clarify or infer which they mean. Option 1, detailed process/flow-level diagrams: decline, out of scope. Option 2, a high-level summary of interactions: build this as a relationship view instead.                                                                                                                                                                                        |
| A class diagram for their solution design                                         | Decline. ArchView doesn't produce detailed-design-level diagrams.                                                                                                                                                                                                                                                                                                                          |

## Intended Restrictions

Here are the intended restrictions, for architectural clarity and conformance:

- **View style is restricted to node-image representation only.** It doesn't render other diagram types such as formal process (e.g., BPMN) views, organization views, tree views, interaction views, class diagrams, matrix/table views, mind maps, and so on. This is *intentional*, to keep the architecture view simple and purposeful. All of these diagram types can still be elevated to an architectural level to support proper representation.
- **The view is restricted to the elements within the specification.** This preserves architectural conformance and avoids inconsistent levels of granularity or representation. The elements focus on enterprise solution architecture (spanning business, application, data, and technical domains) while also reflecting transitional elements from enterprise architecture and solution design. For special edge case elements, you can map to *generic service*, *component*, *system*, or whichever has a closer architectural resemblance. Or you can use the *extension* element if it's remotely related to the solution, such as a facility.
- **There's a maximum node count, to avoid excessive complexity.** For a very complex solution, choose an appropriate level of abstraction and use layering/partitioning elements (grouping, domain, view frame) for clear architectural mapping.

## Tool Limitations and Resolutions

The current tool version has some limitations:

- **Because of the auto-layout, elements in the output view may not appear in the expected order or position.** However, users can customize the layout by moving groups or nodes to their desired positions in the generated HTML page, improving the layering order and overall visual presentation.
- **Each output HTML represents only one area view of the model.** A single HTML output serves one solution aspect. For a fuller model-level mapping, correlate the output views across multiple HTML files. You can check the related archview.json or data.json files (which the user can export as a history record or context in the full-view mode) to validate the overall relationships.

## Link of the Skill Download

- https://github.com/archview/skill
