'use strict';
// render.js
//
// SVG renderer
//
//const { CONFIG } = require('./graph');
const { NODE_LABEL_CONFIG, GROUP_CONFIG, CONFIG } = require('./constants');
const { removeObviousSpacesXml, resolveGroupOverlapsXml } = require('./layout-compact');
// const { DISPLAY } = require('../input/config');
const { renderHTML } = require('./page');
const { parse } = require('./.render');
// const { CONFIG } = require('./graph');
const fs = require('fs');
const path = require('path');
// const { log } = require('console');
//const { GROUP_CONFIG } = require('../input/config');

// const NODE_LABEL_CONFIG = {
//   widthFactor: 4,
//   fontSize: 16,
//   lineHeight: 16,
//   gap: 12,
//   labelTop: 12,
// };

const groupSpaceMargin = 10;
function wrapText(text, maxWidth, fontSize) {
  const words = text.split(/\s+/);

  const lines = [];

  let current = "";

  for (const word of words) {
    const test = current.length === 0 ? word : current + " " + word;

    //
    //  Approximate SVG text width
    //
    const estimatedWidth = test.length * fontSize * 0.8; // 0.6

    if (estimatedWidth > maxWidth && current.length > 0) {
      lines.push(current);

      current = word;
    } else {
      current = test;
    }
  }

  if (current) lines.push(current);

  return lines;
}

function wrapGroupText(text, maxWidth, fontSize) {
  const words = text.split(/\s+/);

  const lines = [];

  let current = "";

  for (const word of words) {
    const test = current.length === 0 ? word : current + " " + word;

    //
    //  Approximate SVG text width
    //
    const estimatedWidth = test.length * fontSize * 0.55; // 0.6

    if (estimatedWidth > maxWidth && current.length > 0) {
      lines.push(current);

      current = word;
    } else {
      current = test;
    }
  }

  if (current) lines.push(current);

  return lines;
}

function renderGraph(
  //  svg,
  graph
) {
  let svg = createSVG("svg");
  svg.setAttribute("id", "graph");
  svg.setAttribute("xmlns", "http://www.w3.org/2000/svg"); // add if you need pure XML

  const root = createSVG("g");

  root.setAttribute("transform", "translate(50,50)");
 
  svg.appendChild(root);

  const groupLayer = createSVG("g");

  const groupEdgeLayer = createSVG("g");

  const edgeLayer = createSVG("g");

  const nodeLayer = createSVG("g");

  const labelLayer = createSVG("g");
  const graphTitleLayer = createSVG("g");
  

  root.appendChild(groupLayer);
  root.appendChild(groupEdgeLayer);
  root.appendChild(edgeLayer);
  root.appendChild(nodeLayer);
  root.appendChild(labelLayer);
  root.appendChild(graphTitleLayer);

  //
  // Groups first
  //
  for (const group of graph.groups) {
    drawGroup(groupLayer, labelLayer, group);
  }

  /*
   * Draw links between groups
   */
  if (graph.groupEdges) {
    for (const edge of graph.groupEdges) {
      drawEdge(groupEdgeLayer, edge);
    }
  }

  //
  // Edges
  //
  for (const edge of graph.edges) {
    drawEdge(edgeLayer, edge);
  }

  //
  // Nodes
  //
  for (const node of graph.nodes) {
    drawNode(nodeLayer, labelLayer, node);
  }


  //  console.log(svg.toString());

  svg = renderTitle(svg, graph, graphTitleLayer);

  //svg = renderTitle2(svg, graph);
  
  const s2= resolveGroupOverlapsXml(svg.toString());


  const s = renderSVG(svg, graph);

   // console.log("svg.height: " + svg.height);


   // ─── Usage ───
// const svgStr = `<svg width="100%" height="100%" viewBox="0 0 800 600">...</svg>`;
// console.log(s);
// const dims = getSVGDimensions(s);

// console.log(JSON.stringify(dims));  

let elemntPropertiesHTML = "";
for (const node of graph.nodes) {
  if (node.properties !=null )
  {
    let s = "" + node.properties;
  // node.properties = node.properties.replace(/\s/g, "")
  if (s.trim() !="")
  elemntPropertiesHTML= elemntPropertiesHTML+ itemToTableRows(node.label, node.properties);
    
  }
}
//  console.log("Out - " + buildTable(elemntPropertiesHTML));



  const s1 = resolveEdgeTextOverlaps(s);  // remove overlapping edge text

  // console.log("__dirname: " + __dirname);

  const csvFile = path.join(__dirname, 'prefix-notation.csv');

  const prefixNotationHTML = createHTMLPrefixTable(graph.nodes, csvFile);

  if (elemntPropertiesHTML.trim() != "")
    elemntPropertiesHTML = buildTable(elemntPropertiesHTML);

  const html = renderHTML(s1, elemntPropertiesHTML, prefixNotationHTML, getTime());

  return html;

 
}


/**
 * Detects overlapping edge text labels in an SVG and clears overlapping ones.
 * Pure Node.js implementation - ZERO dependencies.
 * @param {string} svgString - Raw SVG XML string
 * @returns {string} Modified SVG string with overlapping edge texts blanked
 */
// function resolveEdgeTextOverlaps(svgString) {
//   if (typeof svgString !== 'string') {
//     throw new TypeError('Input must be an SVG string');
//   }

//   // --- 1. Extract edge path IDs ---
//   // Find all <path class="...edge..."> and collect their id attributes
//   const edgePathIds = new Set();
//   const pathRegex = /<path[^>]*>/gi;
//   let pathMatch;
//   while ((pathMatch = pathRegex.exec(svgString)) !== null) {
//     const pathTag = pathMatch[0];
//     const classMatch = pathTag.match(/class\s*=\s*["']([^"']*)["']/i);
//     const idMatch = pathTag.match(/id\s*=\s*["']([^"']*)["']/i);
//     if (classMatch && classMatch[1].includes('edge') && idMatch) {
//       edgePathIds.add(idMatch[1]);
//     }
//   }

//   // --- 2. Extract all <text> elements that match edge IDs ---
//   const edgeTexts = [];
//   const textRegex = /<text[^>]*>.*?<\/text>/gi;
//   let textMatch;
//   while ((textMatch = textRegex.exec(svgString)) !== null) {
//     const textTag = textMatch[0];
//     const idMatch = textTag.match(/id\s*=\s*["']([^"']*)["']/i);
//     if (idMatch && edgePathIds.has(idMatch[1])) {
//       const xMatch = textTag.match(/x\s*=\s*["']([^"']*)["']/i);
//       const yMatch = textTag.match(/y\s*=\s*["']([^"']*)["']/i);
//       const fontSizeMatch = textTag.match(/font-size\s*=\s*["']([^"']*)["']/i);
//       const anchorMatch = textTag.match(/text-anchor\s*=\s*["']([^"']*)["']/i);
      
//       // Extract text content between > and </text>
//       const contentMatch = textTag.match(/>\s*([^<]*)\s*<\/text>/i);
//       const content = contentMatch ? contentMatch[1] : '';

//       edgeTexts.push({
//         fullTag: textMatch[0],
//         startIndex: textMatch.index,
//         endIndex: textMatch.index + textMatch[0].length,
//         id: idMatch[1],
//         x: parseFloat(xMatch ? xMatch[1] : '0'),
//         y: parseFloat(yMatch ? yMatch[1] : '0'),
//         fontSize: parseFloat(fontSizeMatch ? fontSizeMatch[1] : '14'),
//         anchor: anchorMatch ? anchorMatch[1] : 'start',
//         content: content
//       });
//     }
//   }

//   if (edgeTexts.length < 2) {
//     return svgString;
//   }

//   // --- 3. Compute bounding boxes ---
//   const boxes = edgeTexts.map(text => {
//     const fontSize = text.fontSize;
//     const width = text.content.length * fontSize * 0.6;
//     const height = fontSize * 1.2;
//     let x = text.x;
//     const y = text.y;
//     const anchor = text.anchor;

//     if (anchor === 'middle') x -= width / 2;
//     else if (anchor === 'end') x -= width;

//     return {
//       text: text,
//       x: x,
//       y: y - height * 0.85,
//       width: width,
//       height: height,
//       right: x + width,
//       bottom: y - height * 0.85 + height
//     };
//   });

//   // --- 4. Detect AABB overlaps ---
//   const overlappingIndices = new Set();
//   for (let i = 0; i < boxes.length; i++) {
//     for (let j = i + 1; j < boxes.length; j++) {
//       const a = boxes[i];
//       const b = boxes[j];
//       const overlap = (
//         a.x < b.right &&
//         a.right > b.x &&
//         a.y < b.bottom &&
//         a.bottom > b.y
//       );
//       if (overlap) {
//         overlappingIndices.add(i);
//         overlappingIndices.add(j);
//       }
//     }
//   }

//   if (overlappingIndices.size === 0) {
//     return svgString;
//   }

//   // --- 5. Blank out overlapping texts (replace from end to start to preserve indices) ---
//   const sortedByPosition = Array.from(overlappingIndices)
//     .map(idx => ({ idx, start: edgeTexts[idx].startIndex }))
//     .sort((a, b) => b.start - a.start);

//   let result = svgString;
//   for (const { idx } of sortedByPosition) {
//     const text = edgeTexts[idx];
//     const before = result.substring(0, text.startIndex);
//     const after = result.substring(text.endIndex);
    
//     // Keep the tag, remove content between > and </text>
//     const tagOpenEnd = text.fullTag.indexOf('>');
//     const tagCloseStart = text.fullTag.lastIndexOf('</text>');
//     const newTag = text.fullTag.substring(0, tagOpenEnd + 1) + 
//                    text.fullTag.substring(tagCloseStart);
    
//     result = before + newTag + after;
//   }

//   return result;
// }

/**
 * Detects overlapping edge text labels in an SVG and clears overlapping ones.
 * Pure Node.js - ZERO dependencies.
 * 
 * LIMITATION: Node.js has no text rendering engine. Text bounding boxes are
 * estimated using font-size ratios derived from CSS/SVG specs. This is
 * inherently approximate - actual rendering depends on the specific font file.
 * 
 * For pixel-perfect accuracy, use a headless browser or font parsing library.
 * 
 * @param {string} svgString - Raw SVG XML string
 * @returns {string} Modified SVG string with overlapping edge texts blanked
 */
function resolveEdgeTextOverlaps(svgString) {
  if (typeof svgString !== 'string') {
    throw new TypeError('Input must be an SVG string');
  }

  // ---------------------------------------------------------------------------
  // FONT METRIC ESTIMATES
  // ---------------------------------------------------------------------------
  // These ratios are derived from typical Latin font metrics per W3C specs:
  // https://www.w3.org/TR/SVG2/text.html#GlyphMetricsAndLayout
  //
  // In SVG/CSS, 1 EM = font-size. Font metrics are expressed in EM units:
  //   - Glyph advance widths typically range 0.3-0.8 EM (avg ~0.58 for mixed text)
  //   - Line box height = ascent + descent + leading, typically ~1.25 EM
  //   - Alphabetic baseline sits at ~0.8 EM from the top of the line box
  //
  // Since we cannot access the actual font file in Node.js, these are
  // conservative estimates that work for most sans-serif fonts.
  // ---------------------------------------------------------------------------
  const METRICS = Object.freeze({
    AVG_CHAR_WIDTH_EM: 0.58,   // Average glyph advance per character
    LINE_HEIGHT_EM: 1.25,      // Total line box height
    ASCENT_EM: 0.8,            // Baseline to top of line box
    PADDING_EM: 0.05           // Safety margin around each box
  });

  // ---------------------------------------------------------------------------
  // STEP 1: Identify edge paths and collect their IDs
  // ---------------------------------------------------------------------------
  const edgePathIds = new Set();
  const pathRegex = /<path[^>]*>/gi;
  let pathMatch;
  while ((pathMatch = pathRegex.exec(svgString)) !== null) {
    const pathTag = pathMatch[0];
    const classMatch = pathTag.match(/class\s*=\s*["']([^"']*)["']/i);
    const idMatch = pathTag.match(/id\s*=\s*["']([^"']*)["']/i);
    if (classMatch && classMatch[1].includes('edge') && idMatch) {
      edgePathIds.add(idMatch[1]);
    }
  }

  // ---------------------------------------------------------------------------
  // STEP 2: Extract edge text elements with layout properties
  // ---------------------------------------------------------------------------
  const edgeTexts = [];
  const textRegex = /<text[^>]*>.*?<\/text>/gi;
  let textMatch;
  while ((textMatch = textRegex.exec(svgString)) !== null) {
    const textTag = textMatch[0];
    const idMatch = textTag.match(/id\s*=\s*["']([^"']*)["']/i);
    if (idMatch && edgePathIds.has(idMatch[1])) {
      const xMatch = textTag.match(/x\s*=\s*["']([^"']*)["']/i);
      const yMatch = textTag.match(/y\s*=\s*["']([^"']*)["']/i);
      const fontSizeMatch = textTag.match(/font-size\s*=\s*["']([^"']*)["']/i);
      const anchorMatch = textTag.match(/text-anchor\s*=\s*["']([^"']*)["']/i);
      
      const contentMatch = textTag.match(/>\s*([^<]*)\s*<\/text>/i);
      const content = contentMatch ? contentMatch[1] : '';

      let fontSize = 14;
      if (fontSizeMatch) {
        fontSize = parseFloat(fontSizeMatch[1].replace(/px$/, '')) || 14;
      }

      edgeTexts.push({
        fullTag: textMatch[0],
        startIndex: textMatch.index,
        endIndex: textMatch.index + textMatch[0].length,
        id: idMatch[1],
        x: parseFloat(xMatch ? xMatch[1] : '0'),
        y: parseFloat(yMatch ? yMatch[1] : '0'),
        fontSize,
        anchor: anchorMatch ? anchorMatch[1] : 'start',
        content
      });
    }
  }

  if (edgeTexts.length < 2) {
    return svgString;
  }

  // ---------------------------------------------------------------------------
  // STEP 3: Compute bounding boxes from font metrics
  // ---------------------------------------------------------------------------
  // All calculations are in absolute SVG user units, derived from EM ratios.
  const boxes = edgeTexts.map(text => {
    const em = text.fontSize;
    const content = text.content;

    // Width: sum of glyph advances
    // In SVG, each glyph has an "advance width" - the distance to the next glyph.
    // We approximate: total width ≈ char count × font-size × average advance
    const width = content.length * em * METRICS.AVG_CHAR_WIDTH_EM;

    // Height: line box height (ascent + descent + leading)
    const height = em * METRICS.LINE_HEIGHT_EM;

    // The x,y attributes define the initial current text position.
    // Per SVG spec, y is the alphabetic baseline position.
    // text-anchor adjusts which point of the text aligns with x:
    //   start:  left edge of text aligns with x
    //   middle: center of text aligns with x  
    //   end:    right edge of text aligns with x
    let left = text.x;
    if (text.anchor === 'middle') {
      left -= width / 2;
    } else if (text.anchor === 'end') {
      left -= width;
    }

    // The box top is above the baseline by the ascent distance
    const top = text.y - em * METRICS.ASCENT_EM;

    // Add padding for safety margin
    const pad = em * METRICS.PADDING_EM;

    return {
      text,
      x: left - pad,
      y: top - pad,
      right: left + width + pad,
      bottom: top + height + pad
    };
  });

  // ---------------------------------------------------------------------------
  // STEP 4: Detect AABB (Axis-Aligned Bounding Box) overlaps
  // ---------------------------------------------------------------------------
  const overlapping = new Set();
  for (let i = 0; i < boxes.length; i++) {
    for (let j = i + 1; j < boxes.length; j++) {
      const a = boxes[i];
      const b = boxes[j];
      // Two boxes overlap if they intersect on BOTH axes
      const overlapX = a.x < b.right && a.right > b.x;
      const overlapY = a.y < b.bottom && a.bottom > b.y;
      if (overlapX && overlapY) {
        overlapping.add(i);
        overlapping.add(j);
      }
    }
  }

  if (overlapping.size === 0) {
    return svgString;
  }

  // ---------------------------------------------------------------------------
  // STEP 5: Blank out overlapping texts
  // ---------------------------------------------------------------------------
  // Sort by position descending so string indices remain valid during replacement
  const sorted = Array.from(overlapping)
    .map(idx => ({ idx, start: edgeTexts[idx].startIndex }))
    .sort((a, b) => b.start - a.start);

  let result = svgString;
  for (const { idx } of sorted) {
    const t = edgeTexts[idx];
    const before = result.substring(0, t.startIndex);
    const after = result.substring(t.endIndex);
    
    // Replace content between > and </text> with empty string
    const tagOpenEnd = t.fullTag.indexOf('>');
    const tagCloseStart = t.fullTag.lastIndexOf('</text>');
    const newTag = t.fullTag.substring(0, tagOpenEnd + 1) + 
                   t.fullTag.substring(tagCloseStart);
    
    result = before + newTag + after;
  }

  return result;
}



function escapeHtml(text) {
  return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
}

function itemToTableRows_Merge(item, nameValueString) {
  var pairs = nameValueString.split('|');
  var validPairs = [];
  var i, pair, eqIndex, name, value, rowCount, html;

  for (i = 0; i < pairs.length; i = i + 1) {
      if (pairs[i].trim() !== '') {
          validPairs.push(pairs[i]);
      }
  }

  rowCount = validPairs.length;
  html = '';

  if (rowCount === 0) {
      return '<tr><td>' + escapeHtml(item) + '</td><td></td><td></td></tr>';
  }

  for (i = 0; i < validPairs.length; i = i + 1) {
      pair = validPairs[i];
      eqIndex = pair.indexOf('=');
      if (eqIndex > -1) {
          name = pair.slice(0, eqIndex).trim();
          value = pair.slice(eqIndex + 1).trim();
      } else {
          name = pair.trim();
          value = '';
      }

      html = html + '<tr>';
      if (i === 0) {
          html = html + '<td rowspan="' + rowCount + '">' + escapeHtml(item) + '</td>';
      }
      html = html + '<td>' + escapeHtml(name) + '</td>';
      html = html + '<td>' + escapeHtml(value) + '</td>';
      html = html + '</tr>';
  }

  return html;
}

function buildTable_Merge(itemToTableRows) {
  var style = '<style>' +
              'table{border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;}' +
              'th,td{border:1px solid #ccc;padding:8px 12px;text-align:left;vertical-align:top;}' +
              'th{background:#eee;}' +
              'tr:nth-child(even){background:#fafafa;}' +
              '</style>';

  var header = '<table border="1">' +
               '<tr><th>Element</th><th>Property</th><th>Attribute</th></tr>';

  return style + header + itemToTableRows + '</table>';
}


function buildTable(rows) {
  // const rows = data.map(({ item, nameValueString }) => 
  //   itemToTableRows(item, nameValueString)
  // ).join('\n');

  // var style = '<style>' +
  // 'table{border-collapse:collapse;font-family:Arial,sans-serif;font-size:13px;}' +
  // 'th,td{border:1px solid #ccc;padding:8px 12px;text-align:left;vertical-align:top;}' +
  // 'th{background:#eee;}' +
  // 'tr:nth-child(even){background:#fafafa;}' +
  // '</style>';
  var style = '';
  
  return style + "<table border=1 ><thead><tr><th>Element</th><th>Property</th><th>Attribute</th></tr></thead><tbody>" +rows + "</tbody></table>";
}

function itemToTableRows(item, nameValueString) {
  // Split by | and drop empty entries (handles trailing |)
  const pairs = nameValueString.split('|').filter(p => p.trim() !== '');
  
  let html = '';
  
  pairs.forEach((pair, index) => {
    // Split only on the first = so values can contain =
    const eqIndex = pair.indexOf('=');
    const name = eqIndex > -1 ? pair.slice(0, eqIndex).trim() : pair.trim();
    const value = eqIndex > -1 ? pair.slice(eqIndex + 1).trim() : '';
    
    // Item name appears only in the first row; subsequent rows get an empty cell
    const itemCell = index === 0 ? item : '';
    
    html += "<tr><td>" +itemCell+"</td><td>"+ name+"</td><td>"+  value+"</td></tr>";
  });
  
  return html.trim();
}

// // Helper to build the full table from an array of {item, nameValueString}
// function buildTable(data) {
//   const rows = data.map(({ item, nameValueString }) => 
//     itemToTableRows(item, nameValueString)
//   ).join('\n');
  
//   return `<table border="1">
//   <thead>
//     <tr><th>Item</th><th>name</th><th>value</th></tr>
//   </thead>
//   <tbody>
// ${rows}
//   </tbody>
// </table>`;
// }

// // ----- Usage -----
// const data = [
//   { item: 'Item1', nameValueString: "name21=value21|name22=value22 fdg" },
//   { item: 'Item2', nameValueString: "name21=value21 dsd|name22=value22|name23=value23|" }
// ];

// console.log(buildTable(data));
// function getSVGDimensions(svgString) {
//   // Normalize: remove newlines inside the <svg> opening tag so regex works reliably
//   const svgOpen = svgString.match(/<svg[\s\S]*?>/i)?.[0] || '';
//   const normalized = svgOpen.replace(/\s+/g, ' ');
  
//   const widthMatch  = normalized.match(/\swidth=["']([^"']+)["']/i);
//   const heightMatch = normalized.match(/\sheight=["']([^"']+)["']/i);
//   const viewBoxMatch = normalized.match(/\sviewBox=["']([^"']+)["']/i);
  
//   let viewBox = null;
//   if (viewBoxMatch) {
//       const parts = viewBoxMatch[1].trim().split(/[\s,]+/).map(Number);
//       if (parts.length === 4) {
//           viewBox = { x: parts[0], y: parts[1], width: parts[2], height: parts[3] };
//       }
//   }
  
//   const rawWidth  = widthMatch  ? parseFloat(widthMatch[1])  : NaN;
//   const rawHeight = heightMatch ? parseFloat(heightMatch[1]) : NaN;
  
//   return {
//       width:  (rawWidth  > 0) ? rawWidth  : (viewBox ? viewBox.width  : null),
//       height: (rawHeight > 0) ? rawHeight : (viewBox ? viewBox.height : null),
//       viewBox,
//       raw: { width: widthMatch?.[1] || null, height: heightMatch?.[1] || null }
//   };
// }


// function renderTitle2(svg, graph)
// {

//   const outSVG = addBottomSvgTitle2(
//     svg,
//     graph,
//     graphTitle,
//     10,    // inner padding-top inside footer box
//     10,    // inner padding-bottom inside footer box
//     20,    // space between your main graph and footer box top
//     20,    // space between footer box bottom and SVG bottom edge
//     "transparent", //bg color #f5f5f5
//     "#000", // text color
//     36 // text font 48
// );

// return outSVG;

// }

function renderTitle(svg, graph, graphTitleLayer)
{

  const outSVG = addBottomSvgTitle(
    svg,
    graph,
    graphTitleLayer,
    CONFIG.viewTitle,
    20,    // inner padding-top inside footer box 10
    20,    // inner padding-bottom inside footer box 10
    40,    // space between your main graph and footer box top 20
    40,    // space between footer box bottom and SVG bottom edge 20
    "transparent", //bg color #f5f5f5
    "#000", // text color
    20 // text font 48
);

return outSVG;

}

// function addBottomSvgTitle2(
//   svg,
//   graph,
//   titleText,
//   paddingTop = 8,
//   paddingBottom = 8,
//   marginAboveFooter = 20, // gap between main graph content and footer box
//   marginBottom = 15,     // gap between footer box and SVG bottom edge
//   bgColor = "#eeeeee",
//   textColor = "#111",
//   fontSize = 20
// ) {
//   // const svg = document.getElementById(svgId);
//   // if (!svg) {
//   //     console.error(`SVG #${svgId} not found`);
//   //     return;
//   // }

//   const NS = "http://www.w3.org/2000/svg";
//   // Footer background total height
//   const footerBoxHeight = paddingTop + fontSize + paddingBottom;
//   // Total extra vertical space we need to add to SVG
//   const extraHeightNeeded = marginAboveFooter + footerBoxHeight + marginBottom;

//   let svgW, svgH, isViewBox = false;
//   // if (svg.hasAttribute("viewBox")) {
//   //     isViewBox = true;
//   //     const vb = svg.viewBox.baseVal;
//   //     svgW = vb.width;
//   //     svgH = vb.height;
//   //     // Expand viewBox height downward
//   //     svg.viewBox.baseVal.height = svgH + extraHeightNeeded;
//   // } else {
//       // svgW = svg.width.baseVal.value;
//       // svgH = svg.height.baseVal.value;
//       // // Directly increase SVG pixel height
//       // svg.height.baseVal.value = svgH + extraHeightNeeded;
//   // }


//   svgW = graph.width;
//   svgH = graph.height;
//   // Directly increase SVG pixel height
//   svg.height = svgH + extraHeightNeeded;
//   // const newTotalSvgHeight = isViewBox ? svg.viewBox.height : svg.height;
//   const newTotalSvgHeight = svg.height;

//   // Recalculate latest SVG height after expansion
//   // const newTotalSvgHeight = isViewBox ? svg.viewBox.baseVal.height : svg.height.baseVal.value;
//   // Footer Y position
//   const footerY = newTotalSvgHeight - footerBoxHeight - marginBottom;

//   console.log("svgW: " + svgW);
//   console.log("svgH: " + svgH);
//   console.log("newTotalSvgHeight: " + newTotalSvgHeight);
//   console.log("footerY: " + footerY);

//   // Footer background rectangle
//   const bgRect = createSVG(NS, "rect");
//   bgRect.setAttribute("x", 0);
//   bgRect.setAttribute("y", footerY);
//   bgRect.setAttribute("width", svgW);
//   bgRect.setAttribute("height", footerBoxHeight);
//   bgRect.setAttribute("fill", bgColor);

//   // Centered text
//   const titleTextEl = createSVG(NS, "text");
//   titleTextEl.setAttribute("x", svgW / 2);
//   titleTextEl.setAttribute("y", footerY + paddingTop + fontSize * 0.8);
//   titleTextEl.setAttribute("text-anchor", "middle");
//   titleTextEl.setAttribute("fill", textColor);
//   titleTextEl.setAttribute("font-size", fontSize);
//   titleTextEl.setAttribute("font-family", "Arial, sans-serif");
//   titleTextEl.textContent = titleText;

//   svg.appendChild(bgRect);
//   svg.appendChild(titleTextEl);

// return svg;
// }

function addBottomSvgTitle(
  svg,
  graph,
  graphTitleLayer,
  titleText,
  paddingTop = 8,
  paddingBottom = 8,
  marginAboveFooter = 20, // gap between main graph content and footer box
  marginBottom = 15,     // gap between footer box and SVG bottom edge
  bgColor = "#eeeeee",
  textColor = "#111",
  fontSize = 20
) {

  const footerBoxHeight = paddingTop + fontSize + paddingBottom;
  // Total extra vertical space we need to add to SVG
  const extraHeightNeeded = marginAboveFooter + footerBoxHeight + marginBottom;

  let svgW, svgH;
  svgW = graph.width;
  svgH = graph.height;
  // svg.height = svgH + extraHeightNeeded;
  // const newTotalSvgHeight = svg.height;

  // const footerY = newTotalSvgHeight - footerBoxHeight - marginBottom;
  // const footerY = newTotalSvgHeight;
  // console.log("svgW: " + svgW);
  // console.log("y: " + footerY + paddingTop + fontSize * 0.8);
  // console.log("titleText: " + titleText);
  // console.log("footerBoxHeight: " + footerBoxHeight);

  // Centered text
  const titleTextEl = createSVG("text");
  titleTextEl.setAttribute("x", svgW/2);
  // titleTextEl.setAttribute("x", 0);
  // titleTextEl.setAttribute("y", footerY + paddingTop + fontSize * 0.8 - titleTopGap - 500); // no effect for svg
  titleTextEl.setAttribute("y", 10 ); 
  titleTextEl.setAttribute("text-anchor", "middle");
  // titleTextEl.setAttribute("fill", textColor);
  titleTextEl.setAttribute("fill", "transparent");
  titleTextEl.setAttribute("font-size", fontSize);
  titleTextEl.setAttribute("font-family", "Arial, sans-serif");
  titleTextEl.textContent = titleText;
  titleTextEl.setAttribute("class", "title");

  titleTextEl.setAttribute("id", getTimestamp());
  titleTextEl.setAttribute("description", CONFIG.viewDescription);
  titleTextEl.setAttribute("area", CONFIG.viewArea);
  titleTextEl.setAttribute("status", CONFIG.viewStatus);
  titleTextEl.setAttribute("implication", CONFIG.viewImplication);

  // titleTextEl.setAttribute("width", svgW);
  // titleTextEl.setAttribute("height", footerBoxHeight);
// console.log(graphTitle);
// console.log("------------");
// console.log(graph.x);
// console.log(graph.y);
// console.log(graph.width);

//   console.log(graph.height);
//   console.log(extraHeightNeeded);
//   console.log("topGap in render: " + CONFIG.topGap);

 // graph.height = graph.height - CONFIG.topGap*2 - (CONFIG.maxBottom - graph.height) ; // does not seem any effect
 
 
 graph.height = graph.height -CONFIG.topGap + 50 ;
 
  // console.log( " graph.height " + graph.height );
  // console.log( " CONFIG.topGap " + CONFIG.topGap );
  // console.log( "  CONFIG.maxBottom " + CONFIG.maxBottom );
  
  // console.log(CONFIG.maxBottom);
  graphTitleLayer.appendChild(titleTextEl);
 // svg.appendChild(graphTitleLayer);
// console.log(svg.toString());



return svg;
}

function getTime()
{

const date = new Date();

const options = {
year:'2-digit',
month:'2-digit',
day:'2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false, // This is the key
};

let time = ""+ date.toLocaleString('en-US', options);

return time;
}

function getTimestamp()
{

const date = new Date();

const options = {
year:'2-digit',
month:'2-digit',
day:'2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
  hour12: false, // This is the key
};

let time = ""+ date.toLocaleString('en-US', options);

time = time.replace(",","").replace(":","").replace(":","").replace("/","").replace("/","").replace(" ","");
const year = time.substring(4,6);
const month = time.substring(0,2);
const day = time.substring(2,4);
time = time.substring(6);
// console.log(timestamp); // Example output: 1704968973447
time = year + month + day + time;
return time;
}

function drawGroup(layer, labelLayer, group) {


// const CONFIG = {
//   paddingLeft: 60,

//   paddingRight: 60,

//   paddingTop: 30,

//   paddingBottom: 70,

//   titleHeight: 30,
//   labelX: 10,

//   labelY: 30,
// };

  const rect = createSVG("rect");

  rect.setAttribute("id", group.id);

  rect.setAttribute("x", group.x);

  rect.setAttribute("y", group.y);

  // rect.setAttribute("width", group.width + 10); // guc side effect
  rect.setAttribute("width", group.width);

  rect.setAttribute("height", group.height);

  rect.setAttribute("class", "group-box");

  rect.setAttribute("stroke", "#555");

  rect.setAttribute("style", group.style);

  // console.log("group.gcolor: " + group.gcolor);
  rect.setAttribute("fill", group.gcolor);

  if (group.gcolor =="" || group.gcolor == null)
    rect.setAttribute("fill", "white");
    // rect.setAttribute("fill", "#FFFFF0");

  if (group.style === "dotted") {
    rect.setAttribute("stroke-dasharray", "6 4");
  }

  layer.appendChild(rect);

  if (group.label) {
    const text = createSVG("text");

    // if (group.align === "center") {
    //   text.setAttribute("x", group.x + group.width / 2);

    //   text.setAttribute("text-anchor", "middle");
    // } else if (group.align === "right") {
    //   text.setAttribute("x", group.x + group.width - 10);

    //   text.setAttribute("text-anchor", "end");
    // } else {
    //   // default left

      text.setAttribute("x", group.x + 10);

      text.setAttribute("text-anchor", "start");
    // }

    // text.setAttribute("fill", "gray");

    const groupLines = wrapGroupText(
      group.label,

      group.width - 6,

      NODE_LABEL_CONFIG.fontSize
    );

    groupLines.forEach((line, index) => {
      const text = createSVG("text");

      text.setAttribute(
        "x",

        group.x + GROUP_CONFIG.labelX
      );

      text.setAttribute(
        "y",

        +group.y + GROUP_CONFIG.labelY + index * NODE_LABEL_CONFIG.lineHeight
      );

      text.setAttribute("class", "group-label");

      text.setAttribute("id", group.id);
      text.setAttribute("index", index);
     

      text.textContent = line;

      // text.setAttribute("font-size", 32);  // no effect via css
      // text.setAttribute("font-style", "bold");

      labelLayer.appendChild(text);
    });
  }
}

function renderSVG(svg, graph)
{


  svg.setAttribute(
    "viewBox",

     `0 0 ${graph.width + 100} ${graph.height + 1000}`
    

  );

  // svg.setAttribute(
  //   "y",

  //    300
    

  // );
  // svg.setAttribute(
  //   "height",

  //   graph.height
    

  // );

  // svg.setAttribute(
  //   "width",

  //   graph.width +100
    

  // );


    


  const markDef = `
    
    <defs>
    <marker id="arrow" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto" stroke="transparent">
    <path d="M0,0 L0,6 L9,3 z" fill="#555"/>
    </marker>
    </defs> 
    
    `;

  let s = svg.toString();
  const idx = s.indexOf(">");

  const s1 = s.substring(0, idx + 1);
  const s2 = s.substring(idx + 1);

  // complete svg graph
  s = s1 + markDef + s2;
  // console.log(s);
  // document.getElementById("svg-content").innerHTML = s;
return s;
}


// function getSVGDimensions(svgString) {
//   // Extract width
//   const widthMatch = svgString.match(/<svg[^>]*\swidth=["']([^"']+)["']/i);
//   const width = widthMatch ? parseFloat(widthMatch[1]) : null;
  
//   // Extract height
//   const heightMatch = svgString.match(/<svg[^>]*\sheight=["']([^"']+)["']/i);
//   const height = heightMatch ? parseFloat(heightMatch[1]) : null;
  
//   // Extract viewBox
//   const viewBoxMatch = svgString.match(/<svg[^>]*\sviewBox=["']([^"']+)["']/i);
//   let viewBox = null;
//   if (viewBoxMatch) {
//       const parts = viewBoxMatch[1].trim().split(/[\s,]+/).map(Number);
//       if (parts.length === 4) {
//           viewBox = { x: parts[0], y: parts[1], width: parts[2], height: parts[3] };
//       }
//   }
  
//   // Determine effective dimensions
//   // Priority: explicit width/height > viewBox width/height > null
//   return {
//       width:  width  || (viewBox ? viewBox.width  : null),
//       height: height || (viewBox ? viewBox.height : null),
//       viewBox,
//       raw: { width, height }
//   };
// }




function drawNode(layer, labelLayer, node) {
  const image = createSVG("image");

  image.setAttribute("href", node.image);
// image.setAttribute("href", "AA.png"); // testing

  image.setAttribute("id", node.id);

  image.setAttribute("x", node.x);

  image.setAttribute("y", node.y);

  image.setAttribute("width", node.imageWidth);

  image.setAttribute("height", node.imageHeight);

  image.setAttribute("prefix", node.prefix);


  image.setAttribute("group", node.group);

 
  if (node.properties != undefined )
  image.setAttribute("properties", node.properties);

  // console.log("node.prefix: " + node.prefix);
  layer.appendChild(image);

  if (node.label) {
    const lines = wrapText(
      node.label, // gucguc

      node.width * NODE_LABEL_CONFIG.widthFactor,

      NODE_LABEL_CONFIG.fontSize
    );

    lines.forEach((line, index) => {
      const text = createSVG("text");

      text.setAttribute(
        "x",

        node.x + node.width / 2
      );

      text.setAttribute(
        "y",

        node.y +
          //        node.height
          node.imageHeight +
          NODE_LABEL_CONFIG.labelTop +
          NODE_LABEL_CONFIG.gap +
          index * NODE_LABEL_CONFIG.lineHeight
      );

      text.setAttribute(
        "text-anchor",

        "middle"
      );
// node label color takes effect here, no the css, the group label depends on css
      text.setAttribute(
        "fill",

        "#4682b4" // steel blue - better for dark mode
        // "#2563eb" // blue - better for light mode
        // "#6366f1" //indigo - both lighter
      );

      text.setAttribute(
        "font-size",

        NODE_LABEL_CONFIG.fontSize
      );

      // text.setAttribute(
      //   "font-family",

      //   "Segoe UI, Arial, sans-serif"
      // );

      text.textContent = line;

      text.setAttribute(
        "id",

        node.id
      );

      text.setAttribute(
        "index",

        index
      );

      labelLayer.appendChild(text);
    });
  }
}

function drawEdge(layer, edge) {
  const points = edge.points.map((p) => ({
    x: p.x,
    y: p.y,
  }));

  if (!points || points.length < 2) return;

  let d = `M ${points[0].x} ${points[0].y}`;

  for (let i = 1; i < points.length; i++) {
    d += ` L ${points[i].x} ${points[i].y}`;
  }

  const path = createSVG("path");

  path.setAttribute("d", d);

  path.setAttribute("class", "edge");

  path.setAttribute("id", edge.id);

  path.setAttribute("source", edge.source);

  path.setAttribute("target", edge.target);

  path.setAttribute("link", edge.link);

  if (edge.type === "arrow") {
    path.setAttribute("marker-end", "url(#arrow)");
  }

  layer.appendChild(path);

  if (edge.label && points.length > 0) {
    const mid = points[Math.floor(points.length / 2)];

    const text = createSVG("text");

    text.setAttribute("x", mid.x);

    text.setAttribute("y", mid.y - 8); // mid.y - 8

    text.setAttribute("text-anchor", "middle");

    text.setAttribute("font-size", "14px");

    // "#4682b4" // steel blue - better for dark mode
    // "#2563eb" // blue - better for light mode
    // "#6366f1" //indigo - both lighter

    // text.setAttribute("fill", "#333");
  text.setAttribute("fill", "#6366f1");
    text.setAttribute("font-style", "italic"); // guc added

    text.textContent = edge.label;

    // the following determines the mid points
    const length = path.getTotalLength();
    const midpoint = path.getPointAtLength(length / 2);

    text.setAttribute("x", midpoint.x);

    text.setAttribute("y", midpoint.y - 4);

    text.setAttribute("id", edge.id);

    layer.appendChild(text);
  }
}


function createSVG(name) {
  const el = {
    _tag: name,
    _attrs: Object.create(null),
    _children: [],
    _text: "",

    setAttribute(key, value) {
      this._attrs[key] = value;
    },

    appendChild(child) {
      this._children.push(child);
      return child;
    },

    get textContent() {
      return this._text;
    },

    set textContent(val) {
      this._text = String(val ?? "");
      this._children = [];
    },

    toString() {
      const esc = (s) =>
        String(s)
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;");

      const attrs = Object.entries(this._attrs)
        .map(([k, v]) => ` ${esc(k)}="${esc(v)}"`)
        .join("");

      const kids = this._children.map((c) => c.toString()).join("");
      const text = esc(this._text);

      if (!kids && !text) {
        return `<${name}${attrs} />`;
      }
      return `<${name}${attrs}>${kids}${text}</${name}>`;
    },
  };

  // -----------------------------------------------------------------
  // Add path geometry methods when the element is a <path>
  // -----------------------------------------------------------------
  if (name === "path") {
    let _pathCache = null;

    el.getTotalLength = function () {
      if (!_pathCache) _pathCache = parse(this._attrs.d || "");
      return _pathCache.totalLength;
    };

    el.getPointAtLength = function (dist) {
      if (!_pathCache) _pathCache = parse(this._attrs.d || "");
      return _pathCache.pointAt(dist);
    };
  }

  return el;
}

// =========================================================================
// SVG path-data parser + length calculator (no browser DOM required)
// =========================================================================
function parsePathData(d) {
  const tokens = (
    d.match(/[MmLlHhVvCcSsQqTtAaZz]|-?\d*\.?\d+(?:[eE][+-]?\d+)?/g) || []
  ).map((t) =>
    /[a-zA-Z]/.test(t)
      ? { type: "cmd", val: t }
      : { type: "num", val: parseFloat(t) }
  );

  let i = 0;
  let x = 0,
    y = 0; // current point
  let sx = 0,
    sy = 0; // subpath start
  let cpx = 0,
    cpy = 0; // previous control point (for smooth curves)
  const segs = []; // {x1,y1,x2,y2,len,cum}

  function addSeg(nx, ny) {
    const len = Math.hypot(nx - x, ny - y);
    segs.push({ x1: x, y1: y, x2: nx, y2: ny, len });
    x = nx;
    y = ny;
  }

  function take(n) {
    const out = [];
    for (let k = 0; k < n; k++) {
      if (i < tokens.length && tokens[i].type === "num")
        out.push(tokens[i++].val);
      else break;
    }
    return out;
  }

  while (i < tokens.length) {
    if (tokens[i].type !== "cmd") {
      i++;
      continue;
    }
    const cmdTok = tokens[i++].val;
    const cmd = cmdTok.toUpperCase();
    const rel = cmdTok !== cmd;

    switch (cmd) {
      case "M": {
        const [nx, ny] = take(2);
        let cx = nx,
          cy = ny;
        if (rel) {
          cx += x;
          cy += y;
        }
        x = cx;
        y = cy;
        sx = cx;
        sy = cy;
        // implicit linetos
        while (i < tokens.length && tokens[i].type === "num") {
          const [nx2, ny2] = take(2);
          addSeg(rel ? x + nx2 : nx2, rel ? y + ny2 : ny2);
        }
        cpx = x;
        cpy = y;
        break;
      }
      case "L": {
        const [nx, ny] = take(2);
        addSeg(rel ? x + nx : nx, rel ? y + ny : ny);
        cpx = x;
        cpy = y;
        break;
      }
      case "H": {
        const [nx] = take(1);
        addSeg(rel ? x + nx : nx, y);
        cpx = x;
        cpy = y;
        break;
      }
      case "V": {
        const [ny] = take(1);
        addSeg(x, rel ? y + ny : ny);
        cpx = x;
        cpy = y;
        break;
      }
      case "C": {
        const [x1, y1, x2, y2, x3, y3] = take(6);
        const x0 = x,
          y0 = y;
        flattenCubic(
          x0,
          y0,
          rel ? x0 + x1 : x1,
          rel ? y0 + y1 : y1,
          rel ? x0 + x2 : x2,
          rel ? y0 + y2 : y2,
          rel ? x0 + x3 : x3,
          rel ? y0 + y3 : y3,
          addSeg
        );
        cpx = rel ? x0 + x2 : x2;
        cpy = rel ? y0 + y2 : y2;
        break;
      }
      case "S": {
        const [x2, y2, x3, y3] = take(4);
        const x0 = x,
          y0 = y;
        const ax1 = 2 * x0 - cpx,
          ay1 = 2 * y0 - cpy;
        flattenCubic(
          x0,
          y0,
          ax1,
          ay1,
          rel ? x0 + x2 : x2,
          rel ? y0 + y2 : y2,
          rel ? x0 + x3 : x3,
          rel ? y0 + y3 : y3,
          addSeg
        );
        cpx = rel ? x0 + x2 : x2;
        cpy = rel ? y0 + y2 : y2;
        break;
      }
      case "Q": {
        const [x1, y1, x2, y2] = take(4);
        const x0 = x,
          y0 = y;
        flattenQuad(
          x0,
          y0,
          rel ? x0 + x1 : x1,
          rel ? y0 + y1 : y1,
          rel ? x0 + x2 : x2,
          rel ? y0 + y2 : y2,
          addSeg
        );
        cpx = rel ? x0 + x1 : x1;
        cpy = rel ? y0 + y1 : y1;
        break;
      }
      case "T": {
        const [x2, y2] = take(2);
        const x0 = x,
          y0 = y;
        const ax1 = 2 * x0 - cpx,
          ay1 = 2 * y0 - cpy;
        flattenQuad(
          x0,
          y0,
          ax1,
          ay1,
          rel ? x0 + x2 : x2,
          rel ? y0 + y2 : y2,
          addSeg
        );
        cpx = ax1;
        cpy = ay1;
        break;
      }
      case "A": {
        const [rx, ry, rot, fa, fs, nx, ny] = take(7);
        const x0 = x,
          y0 = y;
        flattenArc(
          x0,
          y0,
          rx,
          ry,
          rot,
          fa,
          fs,
          rel ? x0 + nx : nx,
          rel ? y0 + ny : ny,
          addSeg
        );
        cpx = x;
        cpy = y;
        break;
      }
      case "Z": {
        if (x !== sx || y !== sy) addSeg(sx, sy);
        cpx = x;
        cpy = y;
        break;
      }
    }
  }

  let cum = 0;
  for (const s of segs) {
    cum += s.len;
    s.cum = cum;
  }

  return {
    totalLength: cum,
    pointAt(dist) {
      if (segs.length === 0) return { x: 0, y: 0 };
      if (dist <= 0) return { x: segs[0].x1, y: segs[0].y1 };
      if (dist >= cum)
        return { x: segs[segs.length - 1].x2, y: segs[segs.length - 1].y2 };

      let lo = 0,
        hi = segs.length - 1;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (segs[mid].cum < dist) lo = mid + 1;
        else hi = mid;
      }
      const seg = segs[lo];
      const prev = seg.cum - seg.len;
      const t = seg.len > 0 ? (dist - prev) / seg.len : 0;
      return {
        x: seg.x1 + (seg.x2 - seg.x1) * t,
        y: seg.y1 + (seg.y2 - seg.y1) * t,
      };
    },
  };
}

// -------------------------------------------------------------------------
// Curve flattening helpers (adaptive subdivision)
// -------------------------------------------------------------------------
function flattenCubic(x0, y0, x1, y1, x2, y2, x3, y3, addSeg) {
  if (cubicFlatness(x0, y0, x1, y1, x2, y2, x3, y3) < 0.5) {
    addSeg(x3, y3);
    return;
  }
  const q0x = (x0 + x1) / 2,
    q0y = (y0 + y1) / 2;
  const q1x = (x1 + x2) / 2,
    q1y = (y1 + y2) / 2;
  const q2x = (x2 + x3) / 2,
    q2y = (y2 + y3) / 2;
  const r0x = (q0x + q1x) / 2,
    r0y = (q0y + q1y) / 2;
  const r1x = (q1x + q2x) / 2,
    r1y = (q1y + q2y) / 2;
  const s0x = (r0x + r1x) / 2,
    s0y = (r0y + r1y) / 2;
  flattenCubic(x0, y0, q0x, q0y, r0x, r0y, s0x, s0y, addSeg);
  flattenCubic(s0x, s0y, r1x, r1y, q2x, q2y, x3, y3, addSeg);
}

function cubicFlatness(x0, y0, x1, y1, x2, y2, x3, y3) {
  const ux = x3 - x0,
    uy = y3 - y0;
  const len = Math.hypot(ux, uy);
  if (len === 0)
    return Math.hypot(x1 - x0, y1 - y0) + Math.hypot(x2 - x0, y2 - y0);
  return (
    (Math.abs((x1 - x0) * uy - (y1 - y0) * ux) +
      Math.abs((x2 - x0) * uy - (y2 - y0) * ux)) /
    len
  );
}

function flattenQuad(x0, y0, x1, y1, x2, y2, addSeg) {
  if (quadFlatness(x0, y0, x1, y1, x2, y2) < 0.5) {
    addSeg(x2, y2);
    return;
  }
  const q0x = (x0 + x1) / 2,
    q0y = (y0 + y1) / 2;
  const q1x = (x1 + x2) / 2,
    q1y = (y1 + y2) / 2;
  const r0x = (q0x + q1x) / 2,
    r0y = (q0y + q1y) / 2;
  flattenQuad(x0, y0, q0x, q0y, r0x, r0y, addSeg);
  flattenQuad(r0x, r0y, q1x, q1y, x2, y2, addSeg);
}

function quadFlatness(x0, y0, x1, y1, x2, y2) {
  const ux = x2 - x0,
    uy = y2 - y0;
  const len = Math.hypot(ux, uy);
  if (len === 0) return Math.hypot(x1 - x0, y1 - y0);
  return Math.abs((x1 - x0) * uy - (y1 - y0) * ux) / len;
}

function flattenArc(x0, y0, rx, ry, phi, fa, fs, x, y, addSeg) {
  if (x0 === x && y0 === y) return;
  rx = Math.abs(rx);
  ry = Math.abs(ry);
  const phiRad = (phi * Math.PI) / 180;
  const cosP = Math.cos(phiRad);
  const sinP = Math.sin(phiRad);

  const dx = (x0 - x) / 2;
  const dy = (y0 - y) / 2;
  const x1p = cosP * dx + sinP * dy;
  const y1p = -sinP * dx + cosP * dy;

  let lambda = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
  if (lambda > 1) {
    const s = Math.sqrt(lambda);
    rx *= s;
    ry *= s;
  }

  const sign = fa === fs ? -1 : 1;
  const sq = Math.max(
    0,
    (rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p) /
      (rx * rx * y1p * y1p + ry * ry * x1p * x1p)
  );
  const cxp = ((sign * rx * y1p) / ry) * Math.sqrt(sq);
  const cyp = ((-sign * ry * x1p) / rx) * Math.sqrt(sq);

  const cx = cosP * cxp - sinP * cyp + (x0 + x) / 2;
  const cy = sinP * cxp + cosP * cyp + (y0 + y) / 2;

  const ux = (x1p - cxp) / rx;
  const uy = (y1p - cyp) / ry;
  const vx = (-x1p - cxp) / rx;
  const vy = (-y1p - cyp) / ry;

  let theta1 = Math.atan2(uy, ux);
  let deltaTheta = Math.atan2(vy, vx) - Math.atan2(uy, ux);
  if (fs === 0 && deltaTheta > 0) deltaTheta -= 2 * Math.PI;
  if (fs === 1 && deltaTheta < 0) deltaTheta += 2 * Math.PI;

  const n = Math.max(1, Math.ceil(Math.abs(deltaTheta) / (Math.PI / 4)));
  for (let k = 1; k <= n; k++) {
    const angle = theta1 + deltaTheta * (k / n);
    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);
    const px = cosP * rx * cosA - sinP * ry * sinA + cx;
    const py = sinP * rx * cosA + cosP * ry * sinA + cy;
    addSeg(px, py);
  }
}

// function getUniqueNodes(nodes)
// {
// const unique = [];

// for(let i = 0; i < nodes.length; i++){
//   const item = nodes[i];
//   // check if id already exists
//   let exists = false;
//   for(let j = 0; j < unique.length; j++){
//     if(unique[j].id === item.id){
//       exists = true;
//       break;
//     }
//   }
//   if(!exists){
//     unique.push(item);
//   }
// }
// }

function createHTMLPrefixTable(nodes, csvPath = 'test.csv') {
  // Read CSV file
  const csvContent = fs.readFileSync(csvPath, 'utf8');
  
  // Parse CSV into lines
  const lines = csvContent.trim().split('\n');
  const headers = lines[0].split(',');
  
  // Parse data rows into objects
  const csvRows = [];
  for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;
      
      const values = line.split(',');
      const row = {};
      for (let j = 0; j < headers.length; j++) {
          row[headers[j]] = values[j] ? values[j].trim() : '';
      }
      csvRows.push(row);
  }
  
  // Build HTML table
  let html = '<table border="1">';
  
  // Header row
  html += '<tr>';
  for (const header of headers) {
      html += '<th>' + escapeHtml(header).trim()  + '</th>';
  }
  html += '</tr>';
  

  // const seenIds = new Set();

  // const uniqueNodes = nodes.filter(node => {
  //   if (seenIds.has(node.id)) return false;
  //   seenIds.add(node.id);
  //   return true;
  // });
// output: [ { id: 'AA' }, { id: 'CX' } ]



// const getUniqueNodes = [...new Map(nodes.reverse().map(n=>[n.prefix,n])).values()].reverse();
// nodes = getUniqueNodes(nodes);

// nodes = dedupeKeepLast(nodes);
nodes = dedupeAndSort(nodes);

let tableContent = "";
  // Data rows - find matching entries for each node
  for (const node of nodes) {

      const matchingRow = csvRows.find(row => row.Prefix === node.prefix);
      if (matchingRow) {

        tableContent ="containing prefix";
        html += '<tr>';
          for (const header of headers) {
            html += '<td>' + escapeHtml(matchingRow[header])+ '</td>';
          }
          html += '</tr>';
      }
  }
  
  // html += '</table>';
// console.log("tableContent: " + tableContent);
  if (tableContent == "")
    html = "";
    else
  html += '</table>';
  
  return html;
}

function getUniqueSortedNodes(nodes)
{

  
  // Step1: get last occurrence for each num (no mutation)
  const map = new Map(nodes.map(n => [n.prefix, n])); 
  
  // Step2: iterate original nodes, keep only first time we see each num
  const seen = new Set();
  const result = nodes.filter(n => {
    if(seen.has(n.prefix)) return false;
    seen.add(n.prefix);
    return true;
  }).map(n => map.get(n.prefix)); // replace with last‑version object
  

}

function dedupeAndSort(nodes) {
  if (!Array.isArray(nodes)) return [];

  // keep last occurrence by string id
  const map = new Map();
  for (const item of nodes) {
      map.set(item.prefix, item);
  }

  const uniqueItems = Array.from(map.values());

  // sort string id ascending (A‑Z)
  const sortedResult = [...uniqueItems].sort((a, b) => {
      return a.prefix.localeCompare(b.prefix);
  });

  return sortedResult;
}

// // safe function: keep last occurrence by num, returns array always
// // function dedupeKeepLast(nodes) {
// //   // guard: if nodes is null / undefined / not array → return empty array
// //   if (!Array.isArray(nodes)) return [];

// //   const map = new Map();
// //   // fill map, later entries overwrite earlier → keep last item for each num
// //   for (const n of nodes) {
// //     map.set(n.prefix, n);
// //   }

// //   // restore original order: walk original array, take first‑seen keys, get latest object from map
// //   const seen = new Set();
// //   const result = [];
// //   for (const n of nodes) {
// //     if (!seen.has(n.prefix)) {
// //       seen.add(n.prefix);
// //       result.push(map.get(n.prefix));
// //     }
// //   }
// //   return result;
// // }
// function dedupeAndSort(nodes) {
//   // safety guard: return empty array if not an array
//   if (!Array.isArray(nodes)) return [];

//   // step1: keep last occurrence for each num
//   const map = new Map();
//   for (const item of nodes) {
//       map.set(item.prefix, item);
//   }

//   // get unique items from map
//   const uniqueArr = Array.from(map.values());

//   // step2: sort by num ascending
//   const sorted = [...uniqueArr].sort((a, b) => Number(a.prefix) - Number(b.prefix));
 
//   return sorted;
// }

function getUniqueNodes(arr) {
  // safety: if input is null/undefined, return empty array to avoid "not iterable"
  if (!Array.isArray(arr)) {
    return [];
  }

  const result = [];
  for (let i = 0; i < arr.length; i++) {
    const node = arr[i];
    let found = false;
    for (let j = 0; j < result.length; j++) {
      if (result[j].prefix === node.prefix) {
        found = true;
        break;
      }
    }
    if (!found) {
      result.push(node);
    }
  }
  return result; // MUST return array
}

module.exports = { renderGraph };
