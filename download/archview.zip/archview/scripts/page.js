'use strict';
// page.js

// const { DISPLAY } = require('../input/config');
const { CONFIG } = require('./constants');

function renderHTML(svg, elementProperties, prefixNotationHTML, viewTime)
{


//   <button
//   class="tool-btn"
//   id="exportGraphToXML"
//   data-tooltip="Export the arch view as .xml file for customization"
// >
// <i>Export</i>
// </button>


    // const trans = `translate(\${panX}, \${panY}) scale(\${scale})`;
    let properties =""; // descriptions

// buttons for the view with description
let toggleButton = "";
let pdfButton ="";
let divArchText = "";
let textScript = "";
let viewHeader = "";


    if (CONFIG.viewDescription != "")
    {
      // need to fix the issue for the '
      CONFIG.viewDescription= CONFIG.viewDescription.replaceAll("'","");
      CONFIG.viewTitle = CONFIG.viewTitle.replaceAll("'","");
      CONFIG.viewArea = CONFIG.viewArea + " View";
      CONFIG.viewStatus = CONFIG.viewStatus.replaceAll("'","");
      CONFIG.viewImplication = CONFIG.viewImplication.replaceAll("'","");

      elementProperties = ""+elementProperties;
      elementProperties = elementProperties.replaceAll("'","");
      prefixNotationHTML = "" +prefixNotationHTML;
      prefixNotationHTML = prefixNotationHTML.replaceAll("'","");

      // console.log("viewDescription: " + viewDescription);

      let viewTable = "<table border=1 ><thead><tr><th>Property</th><th>Attribute</th></tr></thead><tbody><tr><td>Title</td><td>"+CONFIG.viewTitle+"</td></tr><tr><td>Area</td><td>"+CONFIG.viewArea+"</td></tr><tr><td>Description</td><td>"+CONFIG.viewDescription+"</td></tr><tr><td>Status</td><td>"+CONFIG.viewStatus+"</td></tr><tr><td>Implication</td><td>"+CONFIG.viewImplication+"</td></tr><tr><td>Timestamp</td><td>"+viewTime+"</td></tr></tbody></table>";

      
      const titleStyle = `style=\"padding:2px;margin:0px;background-color:azure; font-size: 14px;color:brown; margin-right:20px; \"`;
      // viewHeader =   "<br><H2><center>ArchView Report</center> </h2><br>";

      viewHeader = "";
      // viewHeader = viewHeader + "<br><div "+ titleStyle+"><center><b>Arch View</b></center></div>";

      // viewHeader = viewHeader + "<br><center>" + CONFIG.viewTitle +"</center><br><br>";
      // properties = "<div "+ titleStyle+"><center><b>"+ CONFIG.viewArea + " View Description</b></center></div><div style=\"font-size: 12px;padding:10px;\">";
      properties = "<br><div "+ titleStyle+"><center><b>View Properties</b></center></div><div style=\"font-size: 12px;padding:10px;\">";
      properties = properties + "<br>" + viewTable + "</div>";

   
      if (elementProperties.trim() != "")
      {
      properties = properties + "<br><br><div "+ titleStyle+"><center><b>Element Properties</b></center></div><br>";
      properties = properties + "<div style=\"font-size: 12px;padding:10px;\">" + elementProperties;
      properties = properties +"</div>";
    }
// console.log("prefixNotationHTML: " + prefixNotationHTML);

    if (prefixNotationHTML.trim() != "")
    {
      properties = properties + "<br><br><div "+ titleStyle+"><center><b>Element Prefix Notation</b></center></div><br>";
      properties = properties + "<div style=\"font-size: 12px;padding:10px;\">" + prefixNotationHTML;
      properties = properties +"<br><br><br><br><br></div>";
    }
//       properties = properties.replaceAll("/", "\/");
// console.log(properties);

// console.log(titleStyle);
// console.log(viewHeader);
// console.log(viewTable);
      pdfButton =`
<button class="tool-btn" id="div1">|</button>

<button
class="tool-btn"
id="saveAsPDF"
data-tooltip="Save the arch view page as pdf report file"
>
Report
</button>


`;

toggleButton = `
<button class="tool-btn" id="div1">|</button>
<button class="tool-btn" id="toggle" data-tooltip="Toggle display mode: Text/View.">Properties</button>

`;

divArchText = `

<div id="archText" style="overflow:auto;top:25px;left:0px;width:100%; height:100%;z-index: 2; background-color:white; padding:10px; display:none; position:absolute;"><div id="output"></div></div><script>document.getElementById('output').innerHTML = ATHTML;</script>


`;

textScript = `

document.getElementById('toggle').addEventListener('click', ()=>{
  toggleView();
});


function toggleView() {
  var divButton = document.getElementById("toggle");
 var archText = document.getElementById("archText");
 var btnZoomIn = document.getElementById("zoomIn");
 var btnZoomOut = document.getElementById("zoomOut");
 var btnReset = document.getElementById("resetZoom");
 var btnCopy = document.getElementById("copyToClipboard");
 var btnPNG = document.getElementById("saveAsPNG");
 var btnExport = document.getElementById("exportGraphToXML");
 var btnData = document.getElementById("exportGraphToJSON");
 let btnPo = document.getElementById("positioning");

 if (archText.style.display === "none") {

  btnPo.style.color = "darkgray";
  btnPo.disabled = true;

  archText.style.display = "block";
  divButton.textContent = "View";

 
  btnZoomIn.style.color = "darkgray";
  btnZoomIn.disabled = true;
  btnZoomOut.style.color = "darkgray";
  btnZoomOut.disabled = true;
  btnReset.style.color = "darkgray";
  btnReset.disabled = true;

  btnCopy.style.color = "darkgray";
  btnCopy.disabled = true;
  btnPNG.style.color = "darkgray";
  btnPNG.disabled = true;
  btnExport.style.color = "darkgray";
  btnExport.disabled = true;


  btnData.style.color = "darkgray";
  btnData.disabled = true;


 } else {

  btnPo.style.color = "white";
  btnPo.disabled = false;

  archText.style.display = "none";
  divButton.textContent = "Properties";

  if (mode =="Zoom"){
  btnZoomIn.style.color = "white";
  btnZoomIn.disabled = false;
  btnZoomOut.style.color = "white";
  btnZoomOut.disabled = false;
  btnReset.style.color = "white";
  btnReset.disabled = false;
  }
  btnCopy.style.color = "white";
  btnCopy.disabled = false;
  btnPNG.style.color = "white";
  btnPNG.disabled = false;
  btnExport.style.color = "white";
  btnExport.disabled = false;
  btnData.style.color = "white";
  btnData.disabled = false;


 }
}


`;
    }

 const html = `

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta
      name="description"
      content="ArchView is an Enterprise Solution Architecture (ESA) modeling tool that includes a list of practical elements, simple yet systematic for various IT architectures. It's a unified architecture model that covers AI, Software Architecture and Design (UML), EA (ArchiMate), Integration & Scalability, Business, and Infrastructure solutions at an abstraction level of ESA. It facilitates different stakeholders to model enterprise solutions for clear objective mapping and reduced cost of change."
    />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>ESA ArchView</title>

    <style>
      .group-label {
        font-size: 18px;
font-family:         Segoe UI, Arial, sans-serif;

        text-anchor: left;
        fill: #4682b4;
      }

      .group-box {
      /*  fill: red; */

        stroke-width: 2;

        padding: 10px;
        margin: 10px;
      }

      .node-label {
        fill: black;

        text-anchor: middle;

        font-family: Arial, Helvetica, sans-serif;
        height: auto;
      }

      .edge {
        fill: none;
        /* none */
        stroke: gray;
        /* #555 */
        stroke-width: 1;
      }
p{
  margin-top:0px;
  margin-bottom:0px;
  padding-bottom:3px;
}
      table {
        border-collapse: collapse;
        font-family: Arial, sans-serif;
        font-size: 12px;
        width:96%
       
      }
      th, td {
        border: 1px solid #ccc;
        padding: 3px 6px;
        text-align: left;
        vertical-align:top;
      }
      th {
        background: #eee;
      }
      tr:nth-child(even){
        background:#fafafa;
      }

    </style>

    <link rel="icon" type="image/x-icon" href="https://diagram.a-esa.com/archiview/sa-favicon.ico" />
  </head>

  <body>
    <div class="topbar">

 
      <button
        class="tool-btn"
        id="zoomIn"
        data-tooltip="Zoom in (+) the arch view" disabled style="color:darkgray;" 
      >
        (+)
      </button>
      <button
        class="tool-btn"
        id="zoomOut"
        data-tooltip="Zoom out (-) the arch view " disabled style="color:darkgray;"
      >
        (-)
      </button>
      <button
        class="tool-btn"
        id="resetZoom"
        data-tooltip="Reset the zoom by default" disabled style="color:darkgray;" 
      >
        Fit
      </button>
      <button
      class="tool-btn"
      id="positioning"
      data-tooltip="Toggle positioning mode: Zoom/Move">Zoom</button>
      <button class="tool-btn" id="div1">|</button>
      <button
        class="tool-btn"
        id="saveAsPNG"
        data-tooltip="Save the arch view as .png image"
      >
        Image
      </button>
      <button
        class="tool-btn"
        id="copyToClipboard"
        data-tooltip="Copy the arch view to clipboard"
      >
        Copy
      </button>
      <button class="tool-btn" id="div1">|</button>
      <button
        class="tool-btn"
        id="exportGraphToJSON"
        data-tooltip="Export as .json file for iteration and record"
      >
        Data
      </button>
  
 
      
${pdfButton}
 
  

      ${toggleButton}
 
    </div>

 

    <div  style="z-index:1; ">
    ${svg}
</div>






   



  
    <script>



    // var btnZoomIn0 = document.getElementById("zoomIn");
    // var btnZoomOut0 = document.getElementById("zoomOut");
    // var btnresetZoom0 = document.getElementById("resetZoom");

    // btnZoomIn0.style.color = "darkgray";
    // btnZoomIn0.disabled = true;
    // btnZoomOu0.style.color = "darkgray";
    // btnZoomOut0.disabled = true;
    // btnresetZoom0.style.color = "darkgray";
    // btnresetZoom0.disabled = true;

    
    // let strPos = "Move";

         document.getElementById("zoomIn").addEventListener("click", () => {
        zoomIn();
      });
      document.getElementById("zoomOut").addEventListener("click", () => {
        zoomOut();
      });
      document.getElementById("resetZoom").addEventListener("click", () => {
        resetZoom();
      });


      document.getElementById('positioning').addEventListener('click', ()=>{
        var divButton = document.getElementById("positioning");

        var btnZoomIn = document.getElementById("zoomIn");
        var btnZoomOut = document.getElementById("zoomOut");
        var btnresetZoom = document.getElementById("resetZoom");

       if (divButton.textContent == "Move")
       {
        divButton.textContent = "Zoom";
        // strPos = "Zoom";

        btnZoomIn.style.color = "darkgray";
        btnZoomIn.disabled = true;
        btnZoomOut.style.color = "darkgray";
        btnZoomOut.disabled = true;
        btnresetZoom.style.color = "darkgray";
        btnresetZoom.disabled = true;


       }
       else
       {
        divButton.textContent = "Move";
        // strPos = "Move";

        btnZoomIn.style.color = "white";
        btnZoomIn.disabled = false;
        btnZoomOut.style.color = "white";
        btnZoomOut.disabled = false;
        btnresetZoom.style.color = "white";
        btnresetZoom.disabled = false;
       }

      });
      
      
    
      
      document.getElementById("saveAsPNG").addEventListener("click", () => {
        saveAsPNG();
      });
      document
        .getElementById("copyToClipboard")
        .addEventListener("click", () => {
          copyToClipboard();
        });
      // document
      //   .getElementById("exportGraphToXML")
      //   .addEventListener("click", () => {
      //     exportGraphToXML();
      //   });
        document
        .getElementById("saveAsPDF")
        .addEventListener("click", () => {
          saveAsPDF();
        });
        document
        .getElementById("exportGraphToJSON")
        .addEventListener("click", () => {
          exportGraphToJSON();
        });
        
        ${textScript}
   
    </script>

<style>
#graph {
    shape-rendering: optimizeSpeed; /* Faster rendering, slightly less crisp */
  }
  #graph g.viewport {
    will-change: transform; /* Hint to browser */
  }
  
  html,
  body {
    margin: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
    font-family: Arial, sans-serif;
  }
  
  #title {
    height: 20px;
    line-height: 20px;
    padding-left: 15px;
    background: #f3f3f3;
    border-bottom: 1px solid #ccc;
  }
  
  #canvas {
    width: 100%;
    height: 100%; 
   /* height: calc(100% - 40px); */
    /*  height:100%;*/
   
  }
  
  svg {
    width: 100%;
    height: 100%;
   
  }
  
  :root {
    --top-h: 20px;
  }
  .topbar {
    height: var(--top-h);
    display: flex;
    align-items: center;
    gap: 2px;
    padding-left: 5px;
    padding-right: 5px;
    padding-top: 0px;
    padding-bottom: 2px;
    background: #0a66c2;
    color: #fff;
  }
  
  .tooltip {
    position: absolute;
    background: #111;
    color: #fff;
    padding: 6px 8px;
    border-radius: 6px;
    font-size: 12px;
    pointer-events: none;
    z-index: 30;
    display: none;
  }
  
  .tool-btn {
    background: transparent;
    border: 0;
    color: inherit;
    padding: 2px 2px;
    border-radius: 6px;
    cursor: pointer;
    margin-top: 4px;
  }
  
  .tool-btn {
    position: relative;
    cursor: pointer;
  }
  
  .tool-btn::after {
    content: attr(data-tooltip);
    visibility: hidden;
    opacity: 0;
    background: #000;
    color: #fff;
    padding: 4px 8px;
    font-size: 12px;
    border-radius: 3px;
    white-space: nowrap;
    position: absolute;
    z-index: 999;
    top: 100%;
    left: 100%;
    margin-top: 5px;
    margin-left: -100%;
    pointer-events: none;
    display: block;
    transition: opacity 0.2s ease;
  }
  
  .tool-btn:hover::after {
    visibility: visible;
    opacity: 1;
  }
  
</style>

<script>

const svg=document.getElementById("graph");let scale=1,panX=0,panY=0,isDragging=!1,startX,startY,viewport=svg.querySelector("g.viewport");if(!viewport){viewport=document.createElementNS("http://www.w3.org/2000/svg","g");for(viewport.classList.add("viewport");svg.firstChild;)viewport.appendChild(svg.firstChild);svg.appendChild(viewport)}function updateTransform(){viewport.setAttribute("transform",\`translate(\${panX}, \${panY}) scale(\${scale})\`)}
function disableSelection(){svg.style.userSelect="none";svg.style.webkitUserSelect="none";svg.style.mozUserSelect="none";svg.style.msUserSelect="none";svg.setAttribute("unselectable","on");document.body.style.userSelect="none";document.body.style.webkitUserSelect="none"}function enableSelection(){}
svg.addEventListener("wheel",a=>{ if (mode=="Move") return; a.preventDefault();var b=svg.getBoundingClientRect();const c=a.clientX-b.left;b=a.clientY-b.top;const d=(b-panY)/scale;a=Math.min(Math.max(scale*(0<a.deltaY?.9:1.1),.1),10);panX=c-(c-panX)/scale*a;panY=b-d*a;scale=a;updateTransform()},{passive:!1});svg.addEventListener("mousedown",a=>{0===a.button&&(isDragging=!0,startX=a.clientX-panX,startY=a.clientY-panY,svg.style.cursor="grabbing",disableSelection())});
window.addEventListener("mousemove",a=>{if (mode=="Move") return; isDragging&&(panX=a.clientX-startX,panY=a.clientY-startY,updateTransform())});window.addEventListener("mouseup",()=>{isDragging&&(isDragging=!1,svg.style.cursor="grab")});window.addEventListener("mouseleave",()=>{isDragging&&(isDragging=!1,svg.style.cursor="grab")});svg.addEventListener("selectstart",a=>a.preventDefault());
function zoomIn(){const a=svg.clientWidth/2,b=svg.clientHeight/2,c=(a-panX)/scale,d=(b-panY)/scale;scale=Math.min(1.2*scale,10);panX=a-c*scale;panY=b-d*scale;updateTransform()}function zoomOut(){const a=svg.clientWidth/2,b=svg.clientHeight/2,c=(a-panX)/scale,d=(b-panY)/scale;scale=Math.max(.8*scale,.1);panX=a-c*scale;panY=b-d*scale;updateTransform()}function resetZoom(){scale=1;panY=panX=0;updateTransform()}svg.style.cursor="grab";

</script>
<script>

function exportGraphToXML(){var g=document.getElementById("graph");g=convertSvgToGraphXml(g.outerHTML);var d=new Blob([g],{type:"application/xml"});d=URL.createObjectURL(d);const e=document.createElement("a");e.href=d;e.download="archview.xml";document.body.appendChild(e);e.click();document.body.removeChild(e);URL.revokeObjectURL(d);return g}
function convertSvgToGraphXml(g){function d(a){return null==a?"":String(a).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function e(a,b){a=Array.from(h.querySelectorAll(b));a.sort((c,k)=>{c=parseInt(c.getAttribute("index")||"0",10);k=parseInt(k.getAttribute("index")||"0",10);return c-k});return a.map(c=>c.textContent.trim()).join(" ")}const h=(new DOMParser).parseFromString(g,"image/svg+xml"),l=[];h.querySelectorAll("image[prefix]").forEach(a=>{const b=a.id,
c=e(b,\`text[id="\${b}"]:not(.group-label)\`);l.push({id:b,type:"node",x:a.getAttribute("x")||"0",y:a.getAttribute("y")||"0",w:a.getAttribute("width")||"0",h:a.getAttribute("height")||"0",key:a.getAttribute("prefix")||"",title:c})});const m=[];h.querySelectorAll("rect.group-box, rect.groupbox").forEach(a=>{const b=a.id,c=e(b,\`text.group-label[id="\${b}"]\`);m.push({id:b,type:"group",x:a.getAttribute("x")||"0",y:a.getAttribute("y")||"0",w:a.getAttribute("width")||"0",h:a.getAttribute("height")||"0",bd:a.getAttribute("style")||
"solid",title:c})});const n=[];h.querySelectorAll('path[id^="e"]').forEach(a=>{var b=a.id;const c=b.replace(/^e/,""),k=(a.getAttribute("marker-end")||"").includes("arrow")?"0":"1",p=a.getAttribute("source")||"";a=a.getAttribute("target")||"";b=(b=h.querySelector(\`text[id="\${b}"]\`))?b.textContent.trim():"";"g"!=p[0]&&"g"!=a[0]&&n.push({id:c,from:p,to:a,straight:k,offset:"0",label:b})});let f="<graph>\\n";f+="  <nodes>\\n";l.forEach(a=>{f+=\`    <node id="\${a.id}" type="\${a.type}" x="\${a.x}" y="\${a.y}" w="\${a.w}" h="\${a.h}" key="\${d(a.key)}" title="\${d(a.title)}"/>\\n\`});
m.forEach(a=>{f+=\`    <node id="\${a.id}" type="\${a.type}" x="\${a.x}" y="\${a.y}" w="\${a.w}" h="\${a.h}" bd="\${d(a.bd)}" title="\${d(a.title)}"/>\\n\`});f+="  </nodes>\\n";f+="  <links>\\n";n.forEach(a=>{f+=\`    <link id="\${a.id}" from="\${a.from}" to="\${a.to}" straight="\${a.straight}" offset="\${a.offset}" label="\${d(a.label)}"/>\\n\`});f+="  </links>\\n";return f+="</graph>"};




</script>
<script>



// ─── CONFIGURABLE RESOLUTION MULTIPLIER ─────────────────────────────────────

const RESOLUTION_SCALE = ` + CONFIG.imageScale + `;

// ─── CONFIGURABLE BORDER SPACING (SVG user units) ───────────────────────────
// Add space around the detected content edges. 
// Set to 0 for a tight crop; increase for padding. Negative values will crop inward.
const BORDER_LEFT   = 40;
const BORDER_RIGHT  = 40;
const BORDER_TOP    = 40;
const BORDER_BOTTOM = 40;

// ─── GET SVG ELEMENT ─────────────────────────────────────────────────────────
/*
const svg = document.getElementById('graph');

if (!svg) {
    console.error('SVG element with id="graph" not found');
}
*/
// ─── INLINE IMAGES (no HTTP dependency) ──────────────────────────────────────

function inlineImages(svgElement) {
    const clone = svgElement.cloneNode(true);
    const images = clone.querySelectorAll('image');
    
    for (const img of images) {
        const href = img.getAttributeNS('http://www.w3.org/1999/xlink', 'href') 
                  || img.getAttribute('href');
        
        if (!href || href.startsWith('data:')) continue;
        
        const domImg = Array.from(document.querySelectorAll('img')).find(
            i => i.src === href || i.src.endsWith(href.split('/').pop())
        );
        
        if (domImg && domImg.complete && domImg.naturalWidth > 0) {
            try {
                const canvas = document.createElement('canvas');
                canvas.width = domImg.naturalWidth;
                canvas.height = domImg.naturalHeight;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(domImg, 0, 0);
                const dataUrl = canvas.toDataURL('image/png');
                img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', dataUrl);
                img.setAttribute('href', dataUrl);
                continue;
            } catch (e) {
                console.warn('Canvas tainted for image:', href);
            }
        }
        
        const svgImg = svgElement.querySelector(\`image[*|href="\${href}"], image[href="\${href}"]\`);
        if (svgImg) {
            const bbox = svgImg.getBBox();
            if (bbox.width > 0 && bbox.height > 0) {
                try {
                    const canvas = document.createElement('canvas');
                    canvas.width = bbox.width;
                    canvas.height = bbox.height;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(svgImg, 0, 0, bbox.width, bbox.height);
                    const dataUrl = canvas.toDataURL('image/png');
                    img.setAttributeNS('http://www.w3.org/1999/xlink', 'href', dataUrl);
                    img.setAttribute('href', dataUrl);
                } catch (e) {
                    console.warn('Cannot inline SVG image:', href);
                }
            }
        }
    }
    
    return clone;
}

// ─── NORMALIZE FONTS ───────────────────────────────────────────────────────

function normalizeFonts(svgElement) {
    const textElements = svgElement.querySelectorAll('text, tspan');
    textElements.forEach(el => {
        if (!el.getAttribute('font-family')) {
            el.setAttribute('font-family', 'Arial, Helvetica, sans-serif');
        }
        if (!el.getAttribute('font-size')) {
            el.setAttribute('font-size', '14px');
        }
        if (!el.getAttribute('text-anchor')) {
            el.setAttribute('text-anchor', 'start');
        }
    });
    
    if (!svgElement.getAttribute('font-family')) {
        svgElement.setAttribute('font-family', 'Arial, Helvetica, sans-serif');
    }
}

// ─── SERIALIZE SVG ──────────────────────────────────────────────────────────

function serializeSVG(svgElement) {
    const clone = inlineImages(svgElement);
    normalizeFonts(clone);
    
    if (!clone.getAttribute('xmlns')) {
        clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    }
    
    // Inline CSS styles
    let inlineStyles = '';
    for (const sheet of document.styleSheets) {
        try {
            for (const rule of sheet.cssRules) {
                inlineStyles += rule.cssText + '\\n';
            }
        } catch (e) {}
    }
    
    if (inlineStyles) {
        const styleEl = document.createElementNS('http://www.w3.org/2000/svg', 'style');
        styleEl.textContent = inlineStyles;
        clone.insertBefore(styleEl, clone.firstChild);
    }
    
    // ─── Determine tight content bounds ───
    let bbox;
    try {
        bbox = svgElement.getBBox();
    } catch (e) {
        const rect = svgElement.getBoundingClientRect();
        bbox = { x: 0, y: 0, width: rect.width, height: rect.height };
    }
    
    // Apply configurable border spacing around the detected content
    const viewX      = bbox.x - BORDER_LEFT;
    const viewY      = bbox.y - BORDER_TOP;
    const viewWidth  = bbox.width + BORDER_LEFT + BORDER_RIGHT;
    const viewHeight = bbox.height + BORDER_TOP + BORDER_BOTTOM;
    
    // Force the clone to render only the content + borders
    clone.setAttribute('viewBox', \`\${viewX} \${viewY} \${viewWidth} \${viewHeight}\`);
    clone.setAttribute('width',  viewWidth);
    clone.setAttribute('height', viewHeight);
    clone.setAttribute('preserveAspectRatio', 'xMidYMid meet');
    
    // Remove percentage-based sizing that causes canvas rendering issues
    clone.style.width  = '';
    clone.style.height = '';
    
    const serializer = new XMLSerializer();
    return { svgString: serializer.serializeToString(clone), viewWidth, viewHeight };
}

// ─── RENDER SVG TO HIGH-RES CANVAS ───────────────────────────────────────────

async function svgToCanvas(svgElement) {
    const { svgString, viewWidth, viewHeight } = serializeSVG(svgElement);
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    
    const img = new Image();
    
    const canvasWidth  = viewWidth  * RESOLUTION_SCALE;
    const canvasHeight = viewHeight * RESOLUTION_SCALE;
    
    const canvas = document.createElement('canvas');
    canvas.width  = canvasWidth;
    canvas.height = canvasHeight;
    const ctx = canvas.getContext('2d');
    
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    
    return new Promise((resolve, reject) => {
        img.onload = () => {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
            
            ctx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
            URL.revokeObjectURL(url);
            resolve({ canvas, viewWidth, viewHeight });
        };
        
        img.onerror = () => {
            URL.revokeObjectURL(url);
            reject(new Error('Failed to render SVG to canvas'));
        };
        
        img.src = url;
    });
}

// ─── SAVE AS HIGH-RES PNG ─────────────────────────────────────────────────────

async function saveAsPNG(filename = 'archview.png') {
    if (!svg) return;
    const { canvas } = await svgToCanvas(svg);
    const pngUrl = canvas.toDataURL('image/png');
    
    const link = document.createElement('a');
    link.download = filename;
    link.href = pngUrl;
    link.click();
}

// ─── COPY TO CLIPBOARD (high-res PNG) ───────────────────────────────────────

async function copyToClipboard() {
    if (!svg) return;
    
    if (!navigator.clipboard || !window.isSecureContext) {
        alert('Clipboard requires HTTPS or localhost. Use Save as PNG instead.');
        return;
    }
    
    try {
        const { canvas } = await svgToCanvas(svg);
        
        const pngBlob = await new Promise((resolve) => {
            canvas.toBlob(resolve, 'image/png');
        });
        
        if (!pngBlob) {
            throw new Error('Canvas toBlob returned null');
        }
        
        await navigator.clipboard.write([
            new ClipboardItem({ 'image/png': pngBlob })
        ]);
        
        console.log('Copied high-res PNG to clipboard');
        
    } catch (err) {
        console.error('Copy failed:', err);
        alert('Copy failed: ' + err.message + '\\nUse Save as PNG instead.');
    }
}





</script>



<script>

//const archTextHTML =document.getElementById("archText").outerHTML; 

// source of truth, for json, pdf and text display
const ATHTML = '`+properties+`';

async function saveAsPDF(filename = 'archview.pdf', htmlContentAbove = '`+viewHeader+`', htmlContentBelow = ATHTML) {
  if (!svg) return;
  
  const { canvas, viewWidth, viewHeight } = await svgToCanvas(svg);
  const imgData = canvas.toDataURL('image/png');
  
  // ─── jsPDF branch ───
  if (typeof jspdf !== 'undefined' || typeof window.jspdf !== 'undefined') {
      const { jsPDF } = window.jspdf || jspdf;
      const aspectRatio = viewHeight / viewWidth;
      const pdfWidth = 210;
      const pdfHeight = pdfWidth * aspectRatio;
      const pdf = new jsPDF({
          orientation: pdfWidth > pdfHeight ? 'landscape' : 'portrait',
          unit: 'mm',
          format: [pdfWidth, Math.max(pdfHeight, 10)]
      });
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(filename);
      return;
  }
  
  // ─── Print window fallback ───
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
      alert('Popup blocked! ');
      return;
  }
  
  const doc = printWindow.document;
  
  // Write a minimal, static HTML shell (no dynamic content here)
  doc.open();
  doc.write(
      '<!DOCTYPE html>' +
      '<html>' +
      '<head><meta charset="utf-8"><title>' + filename + '</title></head>' +
      '<body></body>' +
      '</html>'
  );
  doc.close();
  
  // Inject styles
  const style = doc.createElement('style');
  style.textContent = [
      '@page { size: auto; margin: 15mm; }',
      'body { margin: 0; padding: 0px; font-family: Arial, sans-serif; text-align: center; }',
      '.content-block { text-align: left; max-width: 800px; margin: 0 auto 10px auto; }',
      'img { max-width: 100%; height: auto; display: block; margin: 0 auto 0px auto; }',
      'table {border-collapse: collapse;font-family: Arial, sans-serif;font-size: 12px;width:96%}',
      'th {background: #eee;}',
      'th, td {border: 1px solid #ccc;padding: 3px 6px;text-align: left;vertical-align:top;}',
      'p {margin-top:0px;margin-bottom:0px;padding-bottom:3px;}',
      '@media print {.content-block,.graph-container,table,th,td, div {-webkit-print-color-adjust: exact !important;print-color-adjust: exact !important;}'
  ].join(' ');
  doc.head.appendChild(style);
  
  // Helper: add HTML string safely via innerHTML
  function addHTML(htmlString) {
      if (!htmlString) return;
      const div = doc.createElement('div');
      div.className = 'content-block';
      div.innerHTML = htmlString;
      doc.body.appendChild(div);
  }
  
  // Build page: content above → image → content below
  addHTML(htmlContentAbove);
  
  const img = doc.createElement('img');
  img.src = imgData;
  doc.body.appendChild(img);
  
  addHTML(htmlContentBelow);
  
  // Trigger print
  printWindow.focus();
  setTimeout(() => printWindow.print(), 250);
}



</script>

<script>

function stripHtmlTags(html) {
   return html.replace(/(<([^>]+)>)/gi, "");

  }

function exportGraphToJSON() {

  //console.log("ATHTML: nothing yet " + "");
  //console.log("ATHTML: " + ATHTML);
  // var txtArchText = ATHTML;
   //  var txtArchText = stripHtmlTags(ATHTML);
    // var txtArchText = stripHtmlTags(ATHTML);
    // if (txtArchText != '' && txtArchText.indexOf("View Description") != -1){
    //   txtArchText = txtArchText.replaceAll("View Description", "View Description: ");
    // }


    // try {
    //   console.log("1====");

    //   document.addEventListener("DOMContentLoaded", function() {
    //     // var element = document.getElementById("myElement");

    //    txtArchText =  document.getElementById('archText').textContent;
    //   });
    //    console.log("2====");
    // } catch (error) {
    //   console.log("3====");
    // }

  const svg = document.getElementById('graph');
  if (!svg) {
    console.error('SVG element with id "graph" not found');
    return;
  }

  const result = {
    viewInfo: [],
    groups: [],
    nodes: [],
    edges: []
  };

  // --- Parse Title ---
  const titleEl = svg.querySelector('text.title');
  //console.log("titleEl: "+ titleEl);
  if (titleEl) {
//result.warning = "This json file is for data record only, NOT as an input file for the ArchView generation.";
    const title = titleEl.textContent.trim();
    const description = titleEl.getAttribute('description') || '';
    const area = titleEl.getAttribute('area') || '';
    const status = titleEl.getAttribute('status') || '';
    const implication = titleEl.getAttribute('implication') || '';
    const test = titleEl.getAttribute('test') || '';

    const vi =  {Test:test,Title:title,Description: description, Area:area, Status:status,Implication:implication };
    result.viewInfo.push(vi);
  }

  // --- Parse Groups ---
  const groupBoxes = svg.querySelectorAll('rect.group-box');
  const groupMap = new Map(); // id -> group object
  const groupLabelParts = new Map(); // id -> {index, text}[]

  groupBoxes.forEach(rect => {
    const id = rect.getAttribute('id');
    const style = rect.getAttribute('style') || '';
    groupMap.set(id, { id, label: '', style });
  });

  // Collect group-label parts by index
  const groupLabels = svg.querySelectorAll('text.group-label');
  groupLabels.forEach(labelEl => {
    const id = labelEl.getAttribute('id');
    const index = labelEl.getAttribute('index');
    if (groupMap.has(id) && index !== null) {
      if (!groupLabelParts.has(id)) {
        groupLabelParts.set(id, []);
      }
      groupLabelParts.get(id).push({
        index: parseInt(index, 10),
        text: labelEl.textContent.trim()
      });
    }
  });

  // Build final groups with concatenated labels
  groupMap.forEach((groupObj, id) => {
    if (groupLabelParts.has(id)) {
      const parts = groupLabelParts.get(id);
      parts.sort((a, b) => a.index - b.index);
      groupObj.label = parts.map(p => p.text).join(' ');
    }
    result.groups.push(groupObj);
  });

  // --- Parse Nodes ---
  const images = svg.querySelectorAll('image');
  const nodeMap = new Map(); // id -> node object
  const nodeLabelParts = new Map(); // id -> {index, text}[]

  images.forEach(img => {
    const id = img.getAttribute('id');
    const group = img.getAttribute('group') || '';
    const image = img.getAttribute('prefix') || '';
    const properties = img.getAttribute('properties') || '';
    nodeMap.set(id, { id, group, image, label: '', properties});
  });

  const allTexts = svg.querySelectorAll('text');
  allTexts.forEach(textEl => {
    const id = textEl.getAttribute('id');
    const index = textEl.getAttribute('index');
    const className = textEl.getAttribute('class') || '';

    if (className === 'title' || className === 'group-label') return;

    if (nodeMap.has(id) && index !== null) {
      if (!nodeLabelParts.has(id)) {
        nodeLabelParts.set(id, []);
      }
      nodeLabelParts.get(id).push({
        index: parseInt(index, 10),
        text: textEl.textContent.trim()
      });
    }
  });

  nodeMap.forEach((nodeObj, id) => {
    if (nodeLabelParts.has(id)) {
      const parts = nodeLabelParts.get(id);
      parts.sort((a, b) => a.index - b.index);
      nodeObj.label = parts.map(p => p.text).join(' ');
    }
    result.nodes.push(nodeObj);
  });

  // --- Parse Edges ---
  const edgePaths = svg.querySelectorAll('path.edge');
  const edgeMap = new Map(); // id -> edge object

  edgePaths.forEach(path => {
    const id = path.getAttribute('id');
    const source = path.getAttribute('source') || '';
    const target = path.getAttribute('target') || '';
    const link = path.getAttribute('link') || '';
    const hasArrow = path.getAttribute('marker-end') === 'url(#arrow)';
    const type = hasArrow ? 'arrow' : 'line';

    edgeMap.set(id, { id, source, target, type, label: '', link });
    result.edges.push(edgeMap.get(id));
  });

  allTexts.forEach(textEl => {
    const id = textEl.getAttribute('id');
    const className = textEl.getAttribute('class') || '';
    const index = textEl.getAttribute('index');

    if (className === 'title' || className === 'group-label') return;
    if (index !== null) return;

    if (edgeMap.has(id)) {
      edgeMap.get(id).label = textEl.textContent.trim();
    }
  });

  // --- Download JSON ---
  const jsonStr = JSON.stringify(result, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = 'archview-' + titleEl.getAttribute('id')  +'.json';
  document.body.appendChild(a);
  a.click();

  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}


</script>


<script>

let mode = 'Move'; // 'Pos' = drag nodes/groups, 'Pan' = drag canvas
// Remove the outer IIFE if you had one, or keep it but do NOT conditionally return.
// The key change: check 'mode' INSIDE the handlers, not at setup time.

(function() {
  const svg = document.getElementById('graph');
  const btn = document.getElementById('positioning');


  // Toggle button
  btn.addEventListener('click', function() {
   mode = (mode === 'Move') ? 'Zoom' : 'Move';
// strPos = mode;
   btn.textContent = mode;

       if (mode == "Move")
       {
        btn.textContent   = "Zoom";
       resetZoom();
       }
       else
       {
        btn.textContent  = "Move";
    
       }
     
    svg.style.cursor = (mode === 'Pan') ? 'grab' : '';
  });

  let selectedElement = null;
  let offset = { x: 0, y: 0 };
  let dragType = null; // 'node', 'group', or 'pan'
  let panStart = { clientX: 0, clientY: 0, viewBox: null, scale: 1 };

  // Cursors for positioning mode
  const style = document.createElement('style');
  style.textContent = \`
    image, rect.group-box { cursor: grab; }
    image:active, rect.group-box:active { cursor: grabbing; }
  \`;
  document.head.appendChild(style);

  function getMousePosition(evt) {
    const CTM = svg.getScreenCTM();
    return {
      x: (evt.clientX - CTM.e) / CTM.a,
      y: (evt.clientY - CTM.f) / CTM.d
    };
  }

  function getBounds(el) {
    const x = parseFloat(el.getAttribute('x'));
    const y = parseFloat(el.getAttribute('y'));
    const w = parseFloat(el.getAttribute('width'));
    const h = parseFloat(el.getAttribute('height'));
    return {
      cx: x + w / 2, cy: y + h / 2,
      left: x, right: x + w, top: y, bottom: y + h
    };
  }

  function getBorderPoint(b, dx, dy) {
    let t = Infinity;
    if (Math.abs(dx) > 1e-9) {
      const tX = dx > 0 ? (b.right - b.cx) / dx : (b.left - b.cx) / dx;
      const y = b.cy + tX * dy;
      if (y >= b.top - 1e-9 && y <= b.bottom + 1e-9) t = Math.min(t, tX);
    }
    if (Math.abs(dy) > 1e-9) {
      const tY = dy > 0 ? (b.bottom - b.cy) / dy : (b.top - b.cy) / dy;
      const x = b.cx + tY * dx;
      if (x >= b.left - 1e-9 && x <= b.right + 1e-9) t = Math.min(t, tY);
    }
    if (t === Infinity) return { x: b.cx, y: b.cy };
    return { x: b.cx + t * dx, y: b.cy + t * dy };
  }

  function updateEdges() {
    document.querySelectorAll('path.edge').forEach(function(edge) {
      const edgeId = edge.getAttribute('id');
      const srcId = edge.getAttribute('source');
      const tgtId = edge.getAttribute('target');
      const src = document.querySelector('image[id="' + srcId + '"], rect[id="' + srcId + '"]');
      const tgt = document.querySelector('image[id="' + tgtId + '"], rect[id="' + tgtId + '"]');
      if (src && tgt) {
        const sb = getBounds(src);
        const tb = getBounds(tgt);
        const dx = tb.cx - sb.cx;
        const dy = tb.cy - sb.cy;
        const s = getBorderPoint(sb, dx, dy);
        const t = getBorderPoint(tb, -dx, -dy);
        edge.setAttribute('d', 'M ' + s.x + ' ' + s.y + ' L ' + t.x + ' ' + t.y);
        document.querySelectorAll('text[id="' + edgeId + '"]').forEach(function(lbl) {
          lbl.setAttribute('x', (s.x + t.x) / 2);
          lbl.setAttribute('y', (s.y + t.y) / 2);
        });
      }
    });
  }

  function moveAllTexts(selector, dx, dy) {
    document.querySelectorAll(selector).forEach(function(txt) {
      txt.setAttribute('x', parseFloat(txt.getAttribute('x')) + dx);
      txt.setAttribute('y', parseFloat(txt.getAttribute('y')) + dy);
    });
  }

  // Listeners are attached ONCE, unconditionally
  svg.addEventListener('mousedown', function(evt) {
    // Mode is checked HERE, live, on every click
    if (mode === 'Zoom') {
      dragType = 'pan';
      // panStart.clientX = evt.clientX;
      // panStart.clientY = evt.clientY;
      const vb = (svg.getAttribute('viewBox') || ('0 0 ' + svg.clientWidth + ' ' + svg.clientHeight)).split(/\s+/).map(Number);
      // panStart.viewBox = vb;
      // panStart.scale = svg.getScreenCTM().a;
      svg.style.cursor = 'grabbing';
      evt.preventDefault();
      return;
    }

    // Positioning mode
    const target = evt.target;
    if (target.tagName === 'image') {
      selectedElement = target;
      dragType = 'node';
      const pos = getMousePosition(evt);
      offset.x = pos.x - parseFloat(target.getAttribute('x'));
      offset.y = pos.y - parseFloat(target.getAttribute('y'));
      evt.preventDefault();
    } else if (target.tagName === 'rect' && target.classList.contains('group-box')) {
      selectedElement = target;
      dragType = 'group';
      const pos = getMousePosition(evt);
      offset.x = pos.x - parseFloat(target.getAttribute('x'));
      offset.y = pos.y - parseFloat(target.getAttribute('y'));
      evt.preventDefault();
    }
  });

  svg.addEventListener('mousemove', function(evt) {
    if (!dragType) return;

    // if (dragType === 'pan') {
    //   const dx = (evt.clientX - panStart.clientX) / panStart.scale;
    //   const dy = (evt.clientY - panStart.clientY) / panStart.scale;
    //   const vb = panStart.viewBox;
    //   svg.setAttribute('viewBox', (vb[0] - dx) + ' ' + (vb[1] - dy) + ' ' + vb[2] + ' ' + vb[3]);
    //   return;
    // }

    const pos = getMousePosition(evt);
    const newX = pos.x - offset.x;
    const newY = pos.y - offset.y;
    const oldX = parseFloat(selectedElement.getAttribute('x'));
    const oldY = parseFloat(selectedElement.getAttribute('y'));
    const dx = newX - oldX;
    const dy = newY - oldY;

    if (dragType === 'node') {
      selectedElement.setAttribute('x', newX);
      selectedElement.setAttribute('y', newY);
      moveAllTexts('text[id="' + selectedElement.id + '"]', dx, dy);
      updateEdges();
    } else if (dragType === 'group') {
      selectedElement.setAttribute('x', newX);
      selectedElement.setAttribute('y', newY);
      moveAllTexts('text[id="' + selectedElement.id + '"].group-label', dx, dy);
      document.querySelectorAll('image[group="' + selectedElement.id + '"]').forEach(function(node) {
        node.setAttribute('x', parseFloat(node.getAttribute('x')) + dx);
        node.setAttribute('y', parseFloat(node.getAttribute('y')) + dy);
        moveAllTexts('text[id="' + node.id + '"]', dx, dy);
      });
      updateEdges();
    }
  });

  function endDrag() {
    if (dragType === 'pan') svg.style.cursor = 'grab';
    selectedElement = null;
    dragType = null;
  }

  svg.addEventListener('mouseup', endDrag);
  svg.addEventListener('mouseleave', endDrag);
})();
</script>


${divArchText}


<script src="https://diagram.a-esa.com/archview/avcnt.asp"></script>
</body>
</html>

`;

return html;
}



module.exports = { renderHTML };